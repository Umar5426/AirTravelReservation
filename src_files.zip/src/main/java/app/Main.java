package main.java.app;

import main.java.dao.DatabaseInitializer;
import main.java.gui.LoginWindow;
import main.java.model.TimerSystem;
import main.java.model.MonthlyPromotionEvent;
import main.java.service.NotificationsService;

import java.time.LocalDate;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Ensure DB connection is available before showing UI
        DatabaseInitializer.initializeDatabase();
        
        // Setup monthly promotion notification
        setupMonthlyPromotion();
        
        // Show login window on EDT
        SwingUtilities.invokeLater(() -> {
            new LoginWindow().setVisible(true);
        });
    }
    
    private static void setupMonthlyPromotion() {
        TimerSystem timer = new TimerSystem();
        
        NotificationsService promoService = new NotificationsService() {
            @Override
            protected void onMonthlyPromotion(MonthlyPromotionEvent event) {
                runOnUIThread(() -> {
                    // Use JDialog with proper sizing to prevent text clipping
                    javax.swing.JDialog dialog = new javax.swing.JDialog((java.awt.Frame) null, "Monthly Promotion", true);
                    dialog.setSize(450, 200);
                    dialog.setLocationRelativeTo(null);
                    dialog.setLayout(new java.awt.BorderLayout());
                    
                    javax.swing.JPanel panel = new javax.swing.JPanel();
                    panel.setLayout(new java.awt.BorderLayout());
                    panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20));
                    
                    javax.swing.JLabel messageLabel = new javax.swing.JLabel(
                        "<html><body style='text-align: center; padding: 10px;'>" +
                        "🎉 <b>Monthly Promotion Alert!</b> 🎉<br><br>" +
                        "Check out our special deals for " + event.getMonth() + "!<br>" +
                        "Don't miss out on exclusive flight discounts!" +
                        "</body></html>"
                    );
                    messageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    messageLabel.setPreferredSize(new java.awt.Dimension(400, 120));
                    
                    panel.add(messageLabel, java.awt.BorderLayout.CENTER);
                    
                    javax.swing.JButton okButton = new javax.swing.JButton("OK");
                    okButton.addActionListener(e -> dialog.dispose());
                    javax.swing.JPanel buttonPanel = new javax.swing.JPanel(new java.awt.FlowLayout());
                    buttonPanel.add(okButton);
                    
                    dialog.add(panel, java.awt.BorderLayout.CENTER);
                    dialog.add(buttonPanel, java.awt.BorderLayout.SOUTH);
                    dialog.setVisible(true);
                });
            }
        };
        
        timer.register(promoService);
        
        // Check if today is the 1st of the month
        timer.checkAndNotify(LocalDate.now());
    }
}
