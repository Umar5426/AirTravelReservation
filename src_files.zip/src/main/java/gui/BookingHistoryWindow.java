package main.java.gui;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import main.java.model.Reservation;
import main.java.service.CustomerService;
import main.java.dao.FlightDAO;
import main.java.dao.BookingDAO;

/**
 * Booking History Window
 * 
 * DESIGN PATTERNS:
 * 1. Separation of Concerns - GUI only handles UI, delegates to service layer
 * 2. DAO Pattern - All data access through service layer which uses DAO
 */
public class BookingHistoryWindow extends JFrame {

    private CustomerService customerService;

    /**
     * Constructor
     * DESIGN PATTERN: Service layer handles all business logic
     */
    public BookingHistoryWindow(CustomerService customerService) {
        this.customerService = customerService;

        setTitle("Your Booking History");
        setSize(650, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== Title =====
        JLabel title = new JLabel("Your Reservations", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(title, BorderLayout.NORTH);

        // ===== Main Panel Inside ScrollPane =====
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // ===== FETCH RESERVATIONS =====
        List<Reservation> reservations = customerService.viewBookingHistory();

        if (reservations.isEmpty()) {
            JLabel emptyLabel = new JLabel("No reservations found.", SwingConstants.CENTER);
            emptyLabel.setFont(new Font("Arial", Font.PLAIN, 18));
            add(emptyLabel, BorderLayout.CENTER);
            return;
        }

        for (Reservation r : reservations) {
            JPanel card = createReservationCard(r);
            mainPanel.add(card);
            mainPanel.add(Box.createVerticalStrut(15));
        }

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setBorder(null);
        add(scrollPane, BorderLayout.CENTER);

        // ===== Bottom Buttons =====
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.addActionListener(e -> {
            new MainWindow(false).setVisible(true);
            dispose();
        });

        JPanel bottom = new JPanel();
        bottom.add(backBtn);

        add(bottom, BorderLayout.SOUTH);
    }

    
    // UI FOR EACH RESERVATION
    private JPanel createReservationCard(Reservation r) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY, 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setBackground(new Color(245, 245, 245));

       
        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setOpaque(false);

        info.add(new JLabel("Reservation ID: " + r.getReservationID()));
        info.add(new JLabel("Flight: " + r.getFlight().getFlightCode()));
        info.add(new JLabel("Route: " + r.getFlight().getDepartureAreaCode() + " → " + r.getFlight().getArrivalAreaCode()));
        info.add(new JLabel("Date: " + r.getDateBooked()));
        String seatInfo = r.getSeatNumber() != null ? "Seat: " + r.getSeatNumber() : "Seat: Not assigned";
        info.add(new JLabel(seatInfo));
        info.add(new JLabel("Price: $" + String.format("%.2f", r.getTotalPrice())));

        card.add(info, BorderLayout.CENTER);

        JPanel buttons = new JPanel();
        buttons.setLayout(new GridLayout(2, 1, 10, 10));

        JButton editBtn = new JButton("Edit Reservation");
        JButton cancelBtn = new JButton("Cancel Reservation");

        editBtn.addActionListener(e -> editReservation(r));
        cancelBtn.addActionListener(e -> cancelReservation(r));

        buttons.add(editBtn);
        buttons.add(cancelBtn);

        card.add(buttons, BorderLayout.EAST);

        return card;
    }

    // SERVICE CALLS
    // 
    private void editReservation(Reservation r) {
        // Create edit dialog for seat selection
        JDialog editDialog = new JDialog(this, "Edit Seat - " + r.getReservationID(), true);
        editDialog.setSize(400, 300);
        editDialog.setLocationRelativeTo(this);
        editDialog.setLayout(new BorderLayout());
        
        // Info panel
        JPanel infoPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        infoPanel.add(new JLabel("Flight: " + r.getFlight().getFlightCode()));
        infoPanel.add(new JLabel("Route: " + r.getFlight().getDepartureAreaCode() + " → " + r.getFlight().getArrivalAreaCode()));
        String currentSeat = r.getSeatNumber() != null ? String.valueOf(r.getSeatNumber()) : "Not assigned";
        infoPanel.add(new JLabel("Current Seat: " + currentSeat));
        
        // Seat selection
        infoPanel.add(new JLabel("Select New Seat:"));
        JComboBox<Integer> seatComboBox = new JComboBox<>();
        
        // Load available seats
        try {
            FlightDAO flightDAO = new FlightDAO();
            BookingDAO bookingDAO = new BookingDAO();
            
            int flightId = r.getFlight().getId();
            if (flightId <= 0) {
                flightId = flightDAO.findFlightDbIdByBusinessId(r.getFlight().getFlightID());
            }
            
            if (flightId > 0) {
                // Get booked seats
                List<Integer> bookedSeats = bookingDAO.getBookedSeats(flightId);
                
                // Remove current seat from booked list if it exists
                if (r.getSeatNumber() != null) {
                    bookedSeats.remove(r.getSeatNumber());
                }
                
                // Get all available seats (1 to capacity)
                int capacity = r.getFlight().getCapacity();
                List<Integer> availableSeats = new java.util.ArrayList<>();
                
                for (int seatNum = 1; seatNum <= capacity; seatNum++) {
                    if (!bookedSeats.contains(seatNum)) {
                        availableSeats.add(seatNum);
                    }
                }
                
                // Sort seats
                java.util.Collections.sort(availableSeats);
                
                // Add to combo box
                seatComboBox.addItem(null); // Allow "No seat" option
                for (Integer seat : availableSeats) {
                    seatComboBox.addItem(seat);
                }
                
                // Select current seat if it exists
                if (r.getSeatNumber() != null) {
                    seatComboBox.setSelectedItem(r.getSeatNumber());
                }
            }
        } catch (java.sql.SQLException e) {
            JOptionPane.showMessageDialog(editDialog, 
                "Error loading available seats: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        
        infoPanel.add(seatComboBox);
        
        editDialog.add(infoPanel, BorderLayout.CENTER);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton saveBtn = new JButton("Save");
        JButton cancelBtn = new JButton("Cancel");
        
        saveBtn.addActionListener(e -> {
            Integer newSeat = (Integer) seatComboBox.getSelectedItem();
            
            if (customerService.updateSeatNumber(r.getReservationID(), newSeat)) {
                JOptionPane.showMessageDialog(editDialog, 
                    "Seat updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                editDialog.dispose();
                // Refresh the window
                new BookingHistoryWindow(customerService).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(editDialog, 
                    "Failed to update seat. The seat may already be taken or invalid.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelBtn.addActionListener(e -> editDialog.dispose());
        
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);
        editDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        editDialog.setVisible(true);
    }

    private void cancelReservation(Reservation r) {
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to cancel reservation " + r.getReservationID() + "?",
                "Confirm Cancellation",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            customerService.cancelReservation(r.getReservationID());
            JOptionPane.showMessageDialog(this, "Reservation cancelled.");

            // Refresh page
            new BookingHistoryWindow(customerService).setVisible(true);
            dispose();
        }
    }
}
