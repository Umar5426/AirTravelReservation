package main.java.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

import main.java.dao.FlightDAO;
import main.java.model.AreaCode;
import main.java.model.Flight;

public class FlightInterfaceWindow extends JFrame {
    private FlightDAO flightDAO;
    private JTable flightTable;
    private DefaultTableModel tableModel;
    private JTextField flightIdField;
    private JTextField flightCodeField;
    private JTextField airlineField;
    private JTextField flightDateField;
    private JTextField durationField;
    private JComboBox<AreaCode> departureCombo;
    private JComboBox<AreaCode> arrivalCombo;
    private JTextField capacityField;
    private JTextField priceField;

    public FlightInterfaceWindow() {
        this.flightDAO = new FlightDAO();
        
        setTitle("Flight Management");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Manage Flight Information", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        add(title, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(9, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Flight Details"));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        flightIdField = new JTextField();
        flightCodeField = new JTextField();
        airlineField = new JTextField();
        flightDateField = new JTextField();
        durationField = new JTextField();
        departureCombo = new JComboBox<>(AreaCode.values());
        arrivalCombo = new JComboBox<>(AreaCode.values());
        capacityField = new JTextField();
        priceField = new JTextField();

        formPanel.add(new JLabel("Flight ID:"));
        formPanel.add(flightIdField);
        formPanel.add(new JLabel("Flight Code:"));
        formPanel.add(flightCodeField);
        formPanel.add(new JLabel("Airline:"));
        formPanel.add(airlineField);
        formPanel.add(new JLabel("Flight Date (YYYY-MM-DD):"));
        formPanel.add(flightDateField);
        formPanel.add(new JLabel("Duration:"));
        formPanel.add(durationField);
        formPanel.add(new JLabel("Departure Area Code:"));
        formPanel.add(departureCombo);
        formPanel.add(new JLabel("Arrival Area Code:"));
        formPanel.add(arrivalCombo);
        formPanel.add(new JLabel("Capacity:"));
        formPanel.add(capacityField);
        formPanel.add(new JLabel("Price:"));
        formPanel.add(priceField);

        // Table
        String[] columns = {"ID", "Flight ID", "Code", "Airline", "Date", "From", "To", "Capacity", "Available Seats", "Price"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        flightTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(flightTable);
        
        // Select row to populate form
        flightTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                populateFormFromSelectedRow();
            }
        });

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, formPanel, scrollPane);
        splitPane.setDividerLocation(400);
        add(splitPane, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout());
        JButton addBtn = new JButton("Add Flight");
        JButton updateBtn = new JButton("Update Flight");
        JButton deleteBtn = new JButton("Delete Flight");
        JButton clearBtn = new JButton("Clear Form");
        JButton refreshBtn = new JButton("Refresh");
        JButton backBtn = new JButton("Back");

        btnPanel.add(addBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(deleteBtn);
        btnPanel.add(clearBtn);
        btnPanel.add(refreshBtn);
        btnPanel.add(backBtn);
        add(btnPanel, BorderLayout.SOUTH);

        // Event listeners
        addBtn.addActionListener(e -> addFlight());
        updateBtn.addActionListener(e -> updateFlight());
        deleteBtn.addActionListener(e -> deleteFlight());
        clearBtn.addActionListener(e -> clearForm());
        refreshBtn.addActionListener(e -> refreshTable());
        backBtn.addActionListener(e -> {
            new AdminWindow().setVisible(true);
            dispose();
        });

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        try {
            List<Flight> flights = flightDAO.getAllFlights();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            for (Flight f : flights) {
                // Calculate available seats
                int availableSeats = 0;
                try {
                    int flightId = f.getId();
                    if (flightId > 0) {
                        availableSeats = flightDAO.getAvailableSeats(flightId);
                    } else {
                        // If ID is not set, show capacity as available (new flight)
                        availableSeats = f.getCapacity();
                    }
                } catch (SQLException e) {
                    // If error occurs, show capacity as fallback
                    System.err.println("Error getting available seats: " + e.getMessage());
                    e.printStackTrace();
                    availableSeats = f.getCapacity();
                }
                
                tableModel.addRow(new Object[]{
                    f.getId(),
                    f.getFlightID(),
                    f.getFlightCode(),
                    f.getAirLine(),
                    f.getFlightDate() != null ? sdf.format(f.getFlightDate()) : "",
                    f.getDepartureAreaCode(),
                    f.getArrivalAreaCode(),
                    f.getCapacity(),
                    availableSeats + " / " + f.getCapacity(),
                    f.getPrice()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading flights: " + e.getMessage());
        }
        
        // Set column widths to ensure "Available Seats" column is visible (after table is populated)
        if (flightTable.getColumnCount() > 8) {
            flightTable.getColumnModel().getColumn(8).setPreferredWidth(130); // Available Seats column
        }
    }

    private void populateFormFromSelectedRow() {
        int selectedRow = flightTable.getSelectedRow();
        if (selectedRow == -1) return;

        try {
            int flightId = (Integer) tableModel.getValueAt(selectedRow, 0);
            Flight flight = flightDAO.findById(flightId);
            if (flight != null) {
                flightIdField.setText(flight.getFlightID());
                flightCodeField.setText(flight.getFlightCode());
                airlineField.setText(flight.getAirLine());
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                flightDateField.setText(flight.getFlightDate() != null ? sdf.format(flight.getFlightDate()) : "");
                durationField.setText(flight.getFlightDuration());
                departureCombo.setSelectedItem(flight.getDepartureAreaCode());
                arrivalCombo.setSelectedItem(flight.getArrivalAreaCode());
                capacityField.setText(String.valueOf(flight.getCapacity()));
                priceField.setText(String.valueOf(flight.getPrice()));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading flight: " + e.getMessage());
        }
    }

    private void clearForm() {
        flightIdField.setText("");
        flightCodeField.setText("");
        airlineField.setText("");
        flightDateField.setText("");
        durationField.setText("");
        departureCombo.setSelectedIndex(0);
        arrivalCombo.setSelectedIndex(0);
        capacityField.setText("");
        priceField.setText("");
        flightTable.clearSelection();
    }

    private void addFlight() {
        try {
            java.util.Date flightDate = null;
            if (!flightDateField.getText().trim().isEmpty()) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                flightDate = sdf.parse(flightDateField.getText().trim());
            }

            flightDAO.addFlight(
                flightIdField.getText().trim(),
                flightCodeField.getText().trim(),
                airlineField.getText().trim(),
                flightDate,
                durationField.getText().trim(),
                ((AreaCode) departureCombo.getSelectedItem()).name(),
                ((AreaCode) arrivalCombo.getSelectedItem()).name(),
                Integer.parseInt(capacityField.getText().trim()),
                Double.parseDouble(priceField.getText().trim())
            );
            JOptionPane.showMessageDialog(this, "Flight added successfully!");
            clearForm();
            refreshTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error adding flight: " + e.getMessage());
        }
    }

    private void updateFlight() {
        int selectedRow = flightTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a flight to update.");
            return;
        }

        try {
            int flightId = (Integer) tableModel.getValueAt(selectedRow, 0);
            java.util.Date flightDate = null;
            if (!flightDateField.getText().trim().isEmpty()) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                flightDate = sdf.parse(flightDateField.getText().trim());
            }

            flightDAO.updateFlight(
                flightId,
                flightIdField.getText().trim(),
                flightCodeField.getText().trim(),
                airlineField.getText().trim(),
                flightDate,
                durationField.getText().trim(),
                ((AreaCode) departureCombo.getSelectedItem()).name(),
                ((AreaCode) arrivalCombo.getSelectedItem()).name(),
                Integer.parseInt(capacityField.getText().trim()),
                Double.parseDouble(priceField.getText().trim())
            );
            JOptionPane.showMessageDialog(this, "Flight updated successfully!");
            refreshTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating flight: " + e.getMessage());
        }
    }

    private void deleteFlight() {
        int selectedRow = flightTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a flight to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this flight?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int flightId = (Integer) tableModel.getValueAt(selectedRow, 0);
                flightDAO.deleteFlight(flightId);
                JOptionPane.showMessageDialog(this, "Flight deleted successfully!");
                clearForm();
                refreshTable();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
        }
    }
}
