package main.java.gui;

import java.awt.*;
import java.awt.Dimension;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import main.java.service.CustomerService;
import main.java.service.FlightService;
import main.java.model.Flight;
import java.util.List;

/**
 * Main Window
 * 
 * DESIGN PATTERNS:
 * 1. Separation of Concerns - GUI only handles UI, delegates business logic to services
 * 2. DAO Pattern - All data access through service layer which uses DAO
 */
public class MainWindow extends JFrame {

    private boolean isGuest;
    private boolean isAgent;
    private CustomerService customerService;
    private FlightService flightService;
    private JTable flightTable;
    private DefaultTableModel tableModel;
    private JTextField fromField;
    private JTextField toField;
    private JTextField departDateField;

    public MainWindow() {
        this(true, false); // default guest, not agent
    }

    public MainWindow(boolean isGuest) {
        this(isGuest, false); // not agent by default
    }
    
    public MainWindow(boolean isGuest, boolean isAgent) {
        this.isGuest = isGuest;
        this.isAgent = isAgent;
        this.customerService = new CustomerService();
        this.flightService = new FlightService();

        setTitle("Flight Reservation System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ============================================================
        // TOP TITLE
        // ============================================================
        String titleText = isAgent ? "Flight Agent - Management Panel" : "Book Your Flight";
        JLabel titleLabel = new JLabel(titleText, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(titleLabel, BorderLayout.NORTH);

        // ============================================================
        // LEFT SIDE MENU
        // ============================================================
        int buttonCount = isAgent ? 7 : 5;
        JPanel menuPanel = new JPanel(new GridLayout(buttonCount, 1, 10, 10));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        if (isAgent) {
            // Agent-specific menu
            JButton manageBookingsBtn = new JButton("Manage Bookings");
            JButton manageCustomersBtn = new JButton("Manage Customers");
            JButton searchCustomerBtn = new JButton("Search Customer");
            JButton modifyReservationBtn = new JButton("Modify Reservations");
            JButton viewSchedulesBtn = new JButton("View Schedules");
            JButton refreshBtn = new JButton("Refresh");
            JButton logoutBtn = new JButton("Logout");
            
            menuPanel.add(manageBookingsBtn);
            menuPanel.add(manageCustomersBtn);
            menuPanel.add(searchCustomerBtn);
            menuPanel.add(modifyReservationBtn);
            menuPanel.add(viewSchedulesBtn);
            menuPanel.add(refreshBtn);
            menuPanel.add(logoutBtn);
            
            // Agent button listeners
            manageBookingsBtn.addActionListener(e -> showManageBookings());
            manageCustomersBtn.addActionListener(e -> showManageCustomers());
            searchCustomerBtn.addActionListener(e -> searchCustomerByUsername());
            modifyReservationBtn.addActionListener(e -> showModifyReservations());
            viewSchedulesBtn.addActionListener(e -> showSchedules());
            refreshBtn.addActionListener(e -> {
                loadFeaturedFlights();
                JOptionPane.showMessageDialog(this, "Refreshed!");
            });
            logoutBtn.addActionListener(e -> {
                new LoginWindow().setVisible(true);
                dispose();
            });
        } else {
            // Customer/Guest menu
            JButton searchBtn = new JButton("Search Flights");
            JButton viewBtn = new JButton("View Flight");
            JButton historyBtn = new JButton("Booking History");
            JButton refreshBtn = new JButton("Refresh Flights");
            JButton logoutBtn = new JButton("Logout");

            menuPanel.add(searchBtn);
            menuPanel.add(viewBtn);
            menuPanel.add(historyBtn);
            menuPanel.add(refreshBtn);
            menuPanel.add(logoutBtn);

            // Disable restricted buttons for guests
            if (isGuest) {
                viewBtn.setEnabled(false);
                historyBtn.setEnabled(false);
            }
            
            // Customer button listeners
            searchBtn.addActionListener(e -> {
                FlightSearchWindow fsw = new FlightSearchWindow(isGuest, customerService);
                fsw.setVisible(true);
                dispose();
            });
            
            viewBtn.addActionListener(e -> {
                if (flightTable.getSelectedRow() >= 0) {
                    viewSelectedFlight();
                } else {
                    JOptionPane.showMessageDialog(this, "Please select a flight first.");
                }
            });
            
            historyBtn.addActionListener(e -> new BookingHistoryWindow(customerService).setVisible(true));
            
            refreshBtn.addActionListener(e -> {
                loadFeaturedFlights();
                JOptionPane.showMessageDialog(this, "Flight list refreshed!");
            });
            
            logoutBtn.addActionListener(e -> {
                new LoginWindow().setVisible(true);
                dispose();
            });
        }

        add(menuPanel, BorderLayout.WEST);

        // ============================================================
        // CENTER PANEL — FLIGHT LISTING WITH SEARCH
        // ============================================================
        JPanel centerPanel = new JPanel(new BorderLayout());

        // Search Panel at Top (only for customers, not agents)
        if (!isAgent) {
            JPanel searchPanel = new JPanel();
            searchPanel.setLayout(new GridLayout(2, 4, 10, 10));
            searchPanel.setBorder(BorderFactory.createTitledBorder("Search Flights"));

            fromField = new JTextField();
            toField = new JTextField();
            departDateField = new JTextField();
            JButton searchButton = new JButton("Search");
            JButton refreshSearchBtn = new JButton("Refresh");

            JLabel fromLabel = new JLabel("From (Area Code):");
            fromLabel.setPreferredSize(new Dimension(150, 25));
            searchPanel.add(fromLabel);
            searchPanel.add(fromField);
            JLabel toLabel = new JLabel("To (Area Code):");
            toLabel.setPreferredSize(new Dimension(150, 25));
            searchPanel.add(toLabel);
            searchPanel.add(toField);
            JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
            dateLabel.setPreferredSize(new Dimension(150, 25));
            searchPanel.add(dateLabel);
            searchPanel.add(departDateField);
            searchPanel.add(new JLabel(""));
            JPanel searchButtonPanel = new JPanel(new FlowLayout());
            searchButtonPanel.add(searchButton);
            searchButtonPanel.add(refreshSearchBtn);
            searchPanel.add(searchButtonPanel);
            
            searchButton.addActionListener(e -> {
                String from = fromField.getText().trim();
                String to = toField.getText().trim();
                String date = departDateField.getText().trim();
                
                if (from.isEmpty() || to.isEmpty()) {
                    JOptionPane.showMessageDialog(this,
                            "Enter both departure and arrival area codes.",
                            "Missing Info",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Search and update table (with date if provided)
                searchAndDisplayFlights(from, to, date);
            });
            
            refreshSearchBtn.addActionListener(e -> loadFeaturedFlights());

            centerPanel.add(searchPanel, BorderLayout.NORTH);
        }

        // Featured Flights Table
        String[] columns = {"Flight Code", "Airline", "Date", "From", "To", "Duration", "Price", "Action"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        flightTable = new JTable(tableModel);
        flightTable.setRowHeight(30);
        
        // Double-click to book flight
        flightTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int row = flightTable.rowAtPoint(evt.getPoint());
                    if (row >= 0) {
                        flightTable.setRowSelectionInterval(row, row);
                        viewSelectedFlight();
                    }
                }
            }
        });
        
        // Single click to select
        flightTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && flightTable.getSelectedRow() >= 0) {
                // Row selected, ready for viewing
            }
        });

        JScrollPane scrollPane = new JScrollPane(flightTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Available Flights"));
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        // Load featured flights
        loadFeaturedFlights();

        add(centerPanel, BorderLayout.CENTER);
        
        

    }

    /**
     * Sets the customer service instance (used to preserve login state)
     */
    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
        // Update isGuest flag based on whether customer is logged in
        if (customerService.getLoggedInCustomer() != null) {
            this.isGuest = false;
        }
    }
    
    /**
     * Sets agent mode (enables agent-specific features)
     */
    public void setAgentMode(boolean isAgent) {
        this.isAgent = isAgent;
        if (isAgent) {
            this.isGuest = false; // Agents are not guests
        }
    }
    
    /**
     * Shows manage bookings dialog for agents
     */
    private void showManageBookings() {
        try {
            main.java.dao.BookingDAO bookingDAO = new main.java.dao.BookingDAO();
            main.java.dao.CustomerDAO customerDAO = new main.java.dao.CustomerDAO();
            
            JDialog dialog = new JDialog(this, "Manage Bookings", true);
            dialog.setSize(900, 600);
            dialog.setLocationRelativeTo(this);
            dialog.setLayout(new BorderLayout());
            
            String[] columns = {"Booking ID", "Customer", "Flight Code", "Route", "Date", "Price", "Seat", "Action"};
            DefaultTableModel model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(model);
            JScrollPane scrollPane = new JScrollPane(table);
            
            // Load all bookings
            java.util.List<main.java.model.Customer> customers = customerDAO.getCustomerRecords();
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm");
            for (main.java.model.Customer customer : customers) {
                java.util.List<main.java.model.Reservation> reservations = bookingDAO.getReservationsForCustomer(customer.getId());
                for (main.java.model.Reservation res : reservations) {
                    String route = res.getFlight().getDepartureAreaCode() + " → " + res.getFlight().getArrivalAreaCode();
                    String dateStr = res.getDateBooked() != null ? sdf.format(res.getDateBooked()) : "N/A";
                    String seatStr = res.getSeatNumber() != null ? String.valueOf(res.getSeatNumber()) : "N/A";
                    model.addRow(new Object[]{
                        res.getBookingDbId(),
                        customer.getFname() + " " + customer.getLname(),
                        res.getFlight().getFlightCode(),
                        route,
                        dateStr,
                        "$" + String.format("%.2f", res.getTotalPrice()),
                        seatStr,
                        "Cancel"
                    });
                }
            }
            
            JPanel buttonPanel = new JPanel(new FlowLayout());
            JButton cancelBtn = new JButton("Cancel Selected Booking");
            JButton refreshBtn = new JButton("Refresh");
            JButton closeBtn = new JButton("Close");
            
            cancelBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row < 0) {
                    JOptionPane.showMessageDialog(dialog, "Please select a booking.");
                    return;
                }
                int bookingId = (Integer) model.getValueAt(row, 0);
                int confirm = JOptionPane.showConfirmDialog(dialog, "Cancel booking #" + bookingId + "?");
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        bookingDAO.cancelBooking(bookingId);
                        JOptionPane.showMessageDialog(dialog, "Booking cancelled.");
                        dialog.dispose();
                        showManageBookings(); // Refresh
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
                    }
                }
            });
            
            refreshBtn.addActionListener(e -> {
                dialog.dispose();
                showManageBookings();
            });
            closeBtn.addActionListener(e -> dialog.dispose());
            
            buttonPanel.add(cancelBtn);
            buttonPanel.add(refreshBtn);
            buttonPanel.add(closeBtn);
            
            dialog.add(scrollPane, BorderLayout.CENTER);
            dialog.add(buttonPanel, BorderLayout.SOUTH);
            dialog.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Shows manage customers dialog for agents
     */
    private void showManageCustomers() {
        try {
            main.java.dao.CustomerDAO customerDAO = new main.java.dao.CustomerDAO();
            
            JDialog dialog = new JDialog(this, "Manage Customers", true);
            dialog.setSize(800, 500);
            dialog.setLocationRelativeTo(this);
            dialog.setLayout(new BorderLayout());
            
            String[] columns = {"ID", "Customer ID", "Name", "Username", "Email", "Phone"};
            DefaultTableModel model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(model);
            JScrollPane scrollPane = new JScrollPane(table);
            
            // Load all customers
            java.util.List<main.java.model.Customer> customers = customerDAO.getCustomerRecords();
            for (main.java.model.Customer customer : customers) {
                model.addRow(new Object[]{
                    customer.getId(),
                    customer.getCustomerID(),
                    customer.getFname() + " " + customer.getLname(),
                    customer.getUsername(),
                    customer.getEmail() != null ? customer.getEmail() : "N/A",
                    customer.getPhone() != null ? customer.getPhone() : "N/A"
                });
            }
            
            JPanel buttonPanel = new JPanel(new FlowLayout());
            JButton addBtn = new JButton("Add Customer");
            JButton updateBtn = new JButton("Update Customer");
            JButton removeBtn = new JButton("Remove Customer");
            JButton viewDetailsBtn = new JButton("View Details");
            JButton refreshBtn = new JButton("Refresh");
            JButton closeBtn = new JButton("Close");
            
            addBtn.addActionListener(e -> {
                showAddCustomerDialog(dialog, model);
            });
            
            updateBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row < 0) {
                    JOptionPane.showMessageDialog(dialog, "Please select a customer to update.");
                    return;
                }
                int customerId = (Integer) model.getValueAt(row, 0);
                try {
                    main.java.model.Customer customer = customerDAO.findById(customerId);
                    if (customer != null) {
                        showUpdateCustomerDialog(dialog, customer, model);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
                }
            });
            
            removeBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row < 0) {
                    JOptionPane.showMessageDialog(dialog, "Please select a customer to remove.");
                    return;
                }
                int customerId = (Integer) model.getValueAt(row, 0);
                String customerName = (String) model.getValueAt(row, 2);
                int confirm = JOptionPane.showConfirmDialog(
                    dialog,
                    "Are you sure you want to remove customer: " + customerName + "?",
                    "Confirm Removal",
                    JOptionPane.YES_NO_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        customerDAO.deleteCustomer(customerId);
                        JOptionPane.showMessageDialog(dialog, "Customer removed successfully.");
                        dialog.dispose();
                        showManageCustomers(); // Refresh
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(dialog, "Error removing customer: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }
            });
            
            viewDetailsBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row < 0) {
                    JOptionPane.showMessageDialog(dialog, "Please select a customer.");
                    return;
                }
                int customerId = (Integer) model.getValueAt(row, 0);
                try {
                    main.java.model.Customer customer = customerDAO.findById(customerId);
                    if (customer != null) {
                        main.java.dao.BookingDAO bookingDAO = new main.java.dao.BookingDAO();
                        java.util.List<main.java.model.Reservation> bookings = bookingDAO.getReservationsForCustomer(customerId);
                        StringBuilder details = new StringBuilder();
                        details.append("Customer: ").append(customer.getFname()).append(" ").append(customer.getLname()).append("\n");
                        details.append("Email: ").append(customer.getEmail() != null ? customer.getEmail() : "N/A").append("\n");
                        details.append("Bookings: ").append(bookings.size()).append("\n");
                        JOptionPane.showMessageDialog(dialog, details.toString());
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
                }
            });
            
            refreshBtn.addActionListener(e -> {
                dialog.dispose();
                showManageCustomers();
            });
            closeBtn.addActionListener(e -> dialog.dispose());
            
            buttonPanel.add(addBtn);
            buttonPanel.add(updateBtn);
            buttonPanel.add(removeBtn);
            buttonPanel.add(viewDetailsBtn);
            buttonPanel.add(refreshBtn);
            buttonPanel.add(closeBtn);
            
            dialog.add(scrollPane, BorderLayout.CENTER);
            dialog.add(buttonPanel, BorderLayout.SOUTH);
            dialog.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Shows schedules (all flights) for agents
     */
    private void showSchedules() {
        // Just refresh the flight table - agents can see all flights
        loadFeaturedFlights();
        JOptionPane.showMessageDialog(this, "Showing all flight schedules. Use the table above to view details.");
    }
    
    /**
     * Search by Customer Username - shows all customer data and bookings with cancel option
     */
    private void searchCustomerByUsername() {
        // Create search dialog with input field
        JDialog searchDialog = new JDialog(this, "Search Customer", true);
        searchDialog.setSize(400, 150);
        searchDialog.setLocationRelativeTo(this);
        searchDialog.setLayout(new BorderLayout());
        
        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        inputPanel.add(new JLabel("Customer Username:"));
        JTextField usernameField = new JTextField();
        inputPanel.add(usernameField);
        
        JButton searchBtn = new JButton("Search");
        JButton cancelBtn = new JButton("Cancel");
        
        searchBtn.addActionListener(e -> {
            String username = usernameField.getText().trim();
            if (username.isEmpty()) {
                JOptionPane.showMessageDialog(searchDialog, "Please enter a username.");
                return;
            }
            searchDialog.dispose();
            showCustomerFlights(username);
        });
        
        cancelBtn.addActionListener(e -> searchDialog.dispose());
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(searchBtn);
        buttonPanel.add(cancelBtn);
        
        searchDialog.add(inputPanel, BorderLayout.CENTER);
        searchDialog.add(buttonPanel, BorderLayout.SOUTH);
        searchDialog.setVisible(true);
    }
    
    /**
     * Shows all flights for a customer by username with cancel option
     */
    private void showCustomerFlights(String username) {
        try {
            main.java.dao.CustomerDAO customerDAO = new main.java.dao.CustomerDAO();
            main.java.model.Customer customer = customerDAO.findByUsername(username);
            
            if (customer == null) {
                JOptionPane.showMessageDialog(this, "Customer not found with username: " + username);
                return;
            }
            
            // Get all bookings for this customer
            main.java.dao.BookingDAO bookingDAO = new main.java.dao.BookingDAO();
            java.util.List<main.java.model.Reservation> bookings = bookingDAO.getReservationsForCustomer(customer.getId());
            
            // Create dialog to show customer flights
            JDialog dialog = new JDialog(this, "Customer Flights - " + username, true);
            dialog.setSize(900, 600);
            dialog.setLocationRelativeTo(this);
            dialog.setLayout(new BorderLayout());
            
            // Customer info panel at top
            JPanel infoPanel = new JPanel(new GridLayout(4, 2, 5, 5));
            infoPanel.setBorder(BorderFactory.createTitledBorder("Customer Information"));
            infoPanel.add(new JLabel("Customer ID:"));
            infoPanel.add(new JLabel(customer.getCustomerID()));
            infoPanel.add(new JLabel("Name:"));
            infoPanel.add(new JLabel(customer.getFname() + " " + customer.getLname()));
            infoPanel.add(new JLabel("Username:"));
            infoPanel.add(new JLabel(customer.getUsername()));
            infoPanel.add(new JLabel("Email:"));
            infoPanel.add(new JLabel(customer.getEmail() != null ? customer.getEmail() : "N/A"));
            
            // Bookings table with cancel option
            String[] columns = {"Booking ID", "Flight Code", "Route", "Date", "Price", "Status"};
            DefaultTableModel model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(model);
            table.setRowHeight(30);
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm");
            
            for (main.java.model.Reservation res : bookings) {
                String route = res.getFlight().getDepartureAreaCode() + " → " + res.getFlight().getArrivalAreaCode();
                String dateStr = res.getDateBooked() != null ? sdf.format(res.getDateBooked()) : "N/A";
                model.addRow(new Object[]{
                    res.getBookingDbId(),
                    res.getFlight().getFlightCode(),
                    route,
                    dateStr,
                    "$" + String.format("%.2f", res.getTotalPrice()),
                    "CONFIRMED"
                });
            }
            
            JScrollPane scrollPane = new JScrollPane(table);
            scrollPane.setBorder(BorderFactory.createTitledBorder("Customer Flights (" + bookings.size() + " bookings)"));
            
            // Buttons
            JPanel buttonPanel = new JPanel(new FlowLayout());
            JButton bookFlightBtn = new JButton("Book New Flight");
            JButton cancelBookingBtn = new JButton("Cancel Selected Booking");
            JButton refreshBtn = new JButton("Refresh");
            JButton closeBtn = new JButton("Close");
            
            bookFlightBtn.addActionListener(e -> {
                // Open flight search window for booking
                dialog.dispose();
                FlightSearchWindow fsw = new FlightSearchWindow(false, customerService);
                fsw.setCustomerUsernameForBooking(username); // Pre-fill customer username
                fsw.setVisible(true);
            });
            
            cancelBookingBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row < 0) {
                    JOptionPane.showMessageDialog(dialog, "Please select a booking to cancel.");
                    return;
                }
                int bookingId = (Integer) model.getValueAt(row, 0);
                int confirm = JOptionPane.showConfirmDialog(
                    dialog,
                    "Are you sure you want to cancel booking #" + bookingId + "?",
                    "Confirm Cancellation",
                    JOptionPane.YES_NO_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        bookingDAO.cancelBooking(bookingId);
                        JOptionPane.showMessageDialog(dialog, "Booking cancelled successfully.");
                        dialog.dispose();
                        showCustomerFlights(username); // Refresh
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(dialog, "Error cancelling booking: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }
            });
            
            refreshBtn.addActionListener(e -> {
                dialog.dispose();
                showCustomerFlights(username);
            });
            closeBtn.addActionListener(e -> dialog.dispose());
            
            buttonPanel.add(bookFlightBtn);
            buttonPanel.add(cancelBookingBtn);
            buttonPanel.add(refreshBtn);
            buttonPanel.add(closeBtn);
            
            JPanel centerPanel = new JPanel(new BorderLayout());
            centerPanel.add(infoPanel, BorderLayout.NORTH);
            centerPanel.add(scrollPane, BorderLayout.CENTER);
            
            dialog.add(centerPanel, BorderLayout.CENTER);
            dialog.add(buttonPanel, BorderLayout.SOUTH);
            dialog.setVisible(true);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Shows modify reservations dialog for agents
     */
    private void showModifyReservations() {
        try {
            main.java.dao.BookingDAO bookingDAO = new main.java.dao.BookingDAO();
            main.java.dao.CustomerDAO customerDAO = new main.java.dao.CustomerDAO();
            
            JDialog dialog = new JDialog(this, "Modify Reservations", true);
            dialog.setSize(900, 600);
            dialog.setLocationRelativeTo(this);
            dialog.setLayout(new BorderLayout());
            
            String[] columns = {"Booking ID", "Customer", "Flight Code", "Route", "Date", "Price", "Seat", "Action"};
            DefaultTableModel model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            JTable table = new JTable(model);
            JScrollPane scrollPane = new JScrollPane(table);
            
            // Store reservations for easy access
            java.util.Map<Integer, main.java.model.Reservation> bookingToReservation = new java.util.HashMap<>();
            
            // Load all bookings
            java.util.List<main.java.model.Customer> customers = customerDAO.getCustomerRecords();
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm");
            for (main.java.model.Customer customer : customers) {
                java.util.List<main.java.model.Reservation> reservations = bookingDAO.getReservationsForCustomer(customer.getId());
                for (main.java.model.Reservation res : reservations) {
                    String route = res.getFlight().getDepartureAreaCode() + " → " + res.getFlight().getArrivalAreaCode();
                    String dateStr = res.getDateBooked() != null ? sdf.format(res.getDateBooked()) : "N/A";
                    String seatStr = res.getSeatNumber() != null ? String.valueOf(res.getSeatNumber()) : "N/A";
                    bookingToReservation.put(res.getBookingDbId(), res);
                    model.addRow(new Object[]{
                        res.getBookingDbId(),
                        customer.getFname() + " " + customer.getLname(),
                        res.getFlight().getFlightCode(),
                        route,
                        dateStr,
                        "$" + String.format("%.2f", res.getTotalPrice()),
                        seatStr,
                        "Modify"
                    });
                }
            }
            
            JPanel buttonPanel = new JPanel(new FlowLayout());
            JButton changeSeatBtn = new JButton("Change Seat");
            JButton cancelBtn = new JButton("Cancel Reservation");
            JButton refreshBtn = new JButton("Refresh");
            JButton closeBtn = new JButton("Close");
            
            changeSeatBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row < 0) {
                    JOptionPane.showMessageDialog(dialog, "Please select a reservation.");
                    return;
                }
                int bookingId = (Integer) model.getValueAt(row, 0);
                main.java.model.Reservation res = bookingToReservation.get(bookingId);
                if (res == null) {
                    JOptionPane.showMessageDialog(dialog, "Reservation not found.");
                    return;
                }
                
                // Show seat selection dialog
                showChangeSeatDialog(dialog, res, bookingId);
            });
            
            cancelBtn.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row < 0) {
                    JOptionPane.showMessageDialog(dialog, "Please select a reservation.");
                    return;
                }
                int bookingId = (Integer) model.getValueAt(row, 0);
                int confirm = JOptionPane.showConfirmDialog(dialog, "Cancel booking #" + bookingId + "?");
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        bookingDAO.cancelBooking(bookingId);
                        JOptionPane.showMessageDialog(dialog, "Reservation cancelled.");
                        dialog.dispose();
                        showModifyReservations(); // Refresh
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
                    }
                }
            });
            
            refreshBtn.addActionListener(e -> {
                dialog.dispose();
                showModifyReservations();
            });
            closeBtn.addActionListener(e -> dialog.dispose());
            
            buttonPanel.add(changeSeatBtn);
            buttonPanel.add(cancelBtn);
            buttonPanel.add(refreshBtn);
            buttonPanel.add(closeBtn);
            
            dialog.add(scrollPane, BorderLayout.CENTER);
            dialog.add(buttonPanel, BorderLayout.SOUTH);
            dialog.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Loads featured/prebuilt flights into the table
     * DESIGN PATTERN: DAO Pattern - All data access through service layer
     */
    private void loadFeaturedFlights() {
        try {
            List<Flight> flights = flightService.getAllFlights();
            tableModel.setRowCount(0); // Clear existing rows
            
            // Show first 10 flights as featured
            int count = 0;
            for (Flight flight : flights) {
                if (count >= 10) break; // Limit to 10 featured flights
                addFlightToTable(flight);
                count++;
            }
            
            if (flights.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "No flights available. Please contact administrator.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading flights: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Searches for flights and displays results in table
     * DESIGN PATTERN: DAO Pattern
     */
    private void searchAndDisplayFlights(String from, String to) {
        searchAndDisplayFlights(from, to, null);
    }
    
    /**
     * Searches for flights and displays results in table with date filter
     * DESIGN PATTERN: DAO Pattern
     */
    private void searchAndDisplayFlights(String from, String to, String date) {
        try {
            // Use FlightDAO directly to get Flight objects
            main.java.dao.FlightDAO flightDAO = new main.java.dao.FlightDAO();
            List<Flight> flightResults = flightDAO.searchFlightsAsObjects(from, to, date);
            
            if (flightResults.isEmpty()) {
                String dateMsg = (date != null && !date.isEmpty()) ? "\n- Date matches: " + date : "";
                JOptionPane.showMessageDialog(this,
                        "No flights found for the selected criteria.\n\n" +
                        "Please check:\n" +
                        "- Area codes are correct (e.g., YYC, YVR, YYZ, YUL)\n" +
                        "- Route exists in the system" + dateMsg + "\n\n" +
                        "Showing all available flights...",
                        "No Results",
                        JOptionPane.INFORMATION_MESSAGE);
                // Reload featured flights
                loadFeaturedFlights();
            } else {
                // Clear table first, then add only the search results
                tableModel.setRowCount(0);
                
                // Add found flights to table (only the searched flights)
                for (Flight flight : flightResults) {
                    addFlightToTable(flight);
                }
                
                // Store the search results to restore if Cancel is clicked
                final List<Flight> searchResults = new java.util.ArrayList<>(flightResults);
                
                int result = JOptionPane.showConfirmDialog(this,
                        "Found " + flightResults.size() + " flight(s) for your search.\n\n" +
                        "Click OK to reset search fields and show all flights.\n" +
                        "Click Cancel to keep search fields and these results.",
                        "Search Results",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.INFORMATION_MESSAGE);
                
                // If OK is clicked, reset fields and reload all flights
                if (result == JOptionPane.OK_OPTION) {
                    // Reset search fields
                    if (fromField != null) fromField.setText("");
                    if (toField != null) toField.setText("");
                    if (departDateField != null) departDateField.setText("");
                    
                    // Reload all flights (reset to default view)
                    loadFeaturedFlights();
                } else {
                    // Cancel clicked - restore search results to table
                    // (in case something reset the table)
                    tableModel.setRowCount(0);
                    for (Flight flight : searchResults) {
                        addFlightToTable(flight);
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error searching flights: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    /**
     * Adds a flight to the table
     */
    private void addFlightToTable(Flight flight) {
        String dateStr = "N/A";
        if (flight.getFlightDate() != null) {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
            dateStr = sdf.format(flight.getFlightDate());
        }
        
        Object[] row = {
            flight.getFlightCode() != null ? flight.getFlightCode() : "N/A",
            flight.getAirLine() != null ? flight.getAirLine() : "N/A",
            dateStr,
            flight.getDepartureAreaCode() != null ? flight.getDepartureAreaCode().toString() : "N/A",
            flight.getArrivalAreaCode() != null ? flight.getArrivalAreaCode().toString() : "N/A",
            flight.getFlightDuration() != null ? flight.getFlightDuration() : "N/A",
            "$" + String.format("%.2f", flight.getPrice()),
            "Double-click to Book"
        };
        tableModel.addRow(row);
    }

    /**
     * Views the selected flight and allows booking
     */
    private void viewSelectedFlight() {
        int selectedRow = flightTable.getSelectedRow();
        if (selectedRow < 0) return;

        String flightCode = (String) tableModel.getValueAt(selectedRow, 0);
        Flight flight = customerService.viewFlight(flightCode);
        
        if (flight != null) {
            // Agents can always book (for customers), customers need to be logged in
            if (isAgent) {
                new FlightManagementPanel(customerService, flight, true).setVisible(true);
            } else if (isGuest || customerService.getLoggedInCustomer() == null) {
                JOptionPane.showMessageDialog(this,
                    "Please login or register to book flights.",
                    "Login Required",
                    JOptionPane.INFORMATION_MESSAGE);
                new LoginWindow().setVisible(true);
                dispose();
            } else {
                new FlightManagementPanel(customerService, flight, false).setVisible(true);
            }
        }
    }
    
    /**
     * Shows add customer dialog for agents
     */
    private void showAddCustomerDialog(JDialog parentDialog, DefaultTableModel model) {
        JDialog addDialog = new JDialog(parentDialog, "Add Customer", true);
        addDialog.setSize(500, 500);
        addDialog.setLocationRelativeTo(parentDialog);
        addDialog.setLayout(new BorderLayout());
        
        JPanel formPanel = new JPanel(new GridLayout(9, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField dobField = new JTextField();
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();
        
        formPanel.add(new JLabel("First Name:"));
        formPanel.add(firstNameField);
        formPanel.add(new JLabel("Last Name:"));
        formPanel.add(lastNameField);
        formPanel.add(new JLabel("Date of Birth (YYYY-MM-DD):"));
        formPanel.add(dobField);
        formPanel.add(new JLabel("Username:"));
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Password:"));
        formPanel.add(passwordField);
        formPanel.add(new JLabel("Email:"));
        formPanel.add(emailField);
        formPanel.add(new JLabel("Phone:"));
        formPanel.add(phoneField);
        
        addDialog.add(formPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton saveBtn = new JButton("Save");
        JButton cancelBtn = new JButton("Cancel");
        
        saveBtn.addActionListener(e -> {
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String dobStr = dobField.getText().trim();
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();
            
            if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(addDialog, "Please fill in all required fields.");
                return;
            }
            
            try {
                main.java.dao.CustomerDAO customerDAO = new main.java.dao.CustomerDAO();
                
                // Check if username already exists
                main.java.model.Customer existing = customerDAO.findByUsername(username);
                if (existing != null) {
                    JOptionPane.showMessageDialog(addDialog, "Username already exists.");
                    return;
                }
                
                // Parse date
                java.util.Date dob = null;
                if (!dobStr.isEmpty()) {
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                    dob = sdf.parse(dobStr);
                }
                
                // Generate customer ID
                String customerId = customerDAO.generateNextCustomerId();
                
                // Add customer
                customerDAO.addCustomer(customerId, firstName, lastName, dob, username, password,
                                       email.isEmpty() ? null : email, phone.isEmpty() ? null : phone);
                
                JOptionPane.showMessageDialog(addDialog, "Customer added successfully!");
                addDialog.dispose();
                parentDialog.dispose();
                showManageCustomers(); // Refresh
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(addDialog, "Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
        
        cancelBtn.addActionListener(e -> addDialog.dispose());
        
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);
        addDialog.add(buttonPanel, BorderLayout.SOUTH);
        addDialog.setVisible(true);
    }
    
    /**
     * Shows update customer dialog for agents
     */
    private void showUpdateCustomerDialog(JDialog parentDialog, main.java.model.Customer customer, DefaultTableModel model) {
        JDialog updateDialog = new JDialog(parentDialog, "Update Customer", true);
        updateDialog.setSize(500, 500);
        updateDialog.setLocationRelativeTo(parentDialog);
        updateDialog.setLayout(new BorderLayout());
        
        JPanel formPanel = new JPanel(new GridLayout(9, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JTextField firstNameField = new JTextField(customer.getFname());
        JTextField lastNameField = new JTextField(customer.getLname());
        JTextField dobField = new JTextField();
        JTextField usernameField = new JTextField(customer.getUsername());
        JPasswordField passwordField = new JPasswordField();
        passwordField.setText(customer.getPassword());
        JTextField emailField = new JTextField(customer.getEmail() != null ? customer.getEmail() : "");
        JTextField phoneField = new JTextField(customer.getPhone() != null ? customer.getPhone() : "");
        
        if (customer.getDob() != null) {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
            dobField.setText(sdf.format(customer.getDob()));
        }
        
        formPanel.add(new JLabel("First Name:"));
        formPanel.add(firstNameField);
        formPanel.add(new JLabel("Last Name:"));
        formPanel.add(lastNameField);
        formPanel.add(new JLabel("Date of Birth (YYYY-MM-DD):"));
        formPanel.add(dobField);
        formPanel.add(new JLabel("Username:"));
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Password:"));
        formPanel.add(passwordField);
        formPanel.add(new JLabel("Email:"));
        formPanel.add(emailField);
        formPanel.add(new JLabel("Phone:"));
        formPanel.add(phoneField);
        
        updateDialog.add(formPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton saveBtn = new JButton("Save");
        JButton cancelBtn = new JButton("Cancel");
        
        saveBtn.addActionListener(e -> {
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String dobStr = dobField.getText().trim();
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();
            
            if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(updateDialog, "Please fill in all required fields.");
                return;
            }
            
            try {
                main.java.dao.CustomerDAO customerDAO = new main.java.dao.CustomerDAO();
                
                // Check if username is taken by another customer
                main.java.model.Customer existing = customerDAO.findByUsername(username);
                if (existing != null && existing.getId() != customer.getId()) {
                    JOptionPane.showMessageDialog(updateDialog, "Username already taken by another customer.");
                    return;
                }
                
                // Parse date
                java.util.Date dob = null;
                if (!dobStr.isEmpty()) {
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                    dob = sdf.parse(dobStr);
                }
                
                // Update customer
                customerDAO.updateCustomer(customer.getId(), customer.getCustomerID(), firstName, lastName, dob,
                                          username, password, email.isEmpty() ? null : email, phone.isEmpty() ? null : phone);
                
                JOptionPane.showMessageDialog(updateDialog, "Customer updated successfully!");
                updateDialog.dispose();
                parentDialog.dispose();
                showManageCustomers(); // Refresh
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(updateDialog, "Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
        
        cancelBtn.addActionListener(e -> updateDialog.dispose());
        
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);
        updateDialog.add(buttonPanel, BorderLayout.SOUTH);
        updateDialog.setVisible(true);
    }
    
    /**
     * Shows dialog for agents to change a customer's seat
     */
    private void showChangeSeatDialog(JDialog parentDialog, main.java.model.Reservation res, int bookingId) {
        JDialog seatDialog = new JDialog(parentDialog, "Change Seat - Booking #" + bookingId, true);
        seatDialog.setSize(400, 300);
        seatDialog.setLocationRelativeTo(parentDialog);
        seatDialog.setLayout(new BorderLayout());
        
        JPanel infoPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        infoPanel.add(new JLabel("Flight: " + res.getFlight().getFlightCode()));
        infoPanel.add(new JLabel("Route: " + res.getFlight().getDepartureAreaCode() + " → " + res.getFlight().getArrivalAreaCode()));
        String currentSeat = res.getSeatNumber() != null ? String.valueOf(res.getSeatNumber()) : "Not assigned";
        infoPanel.add(new JLabel("Current Seat: " + currentSeat));
        
        infoPanel.add(new JLabel("Select New Seat:"));
        JComboBox<Integer> seatComboBox = new JComboBox<>();
        
        // Load available seats
        try {
            main.java.dao.FlightDAO flightDAO = new main.java.dao.FlightDAO();
            main.java.dao.BookingDAO bookingDAO = new main.java.dao.BookingDAO();
            
            int flightId = res.getFlight().getId();
            if (flightId <= 0) {
                flightId = flightDAO.findFlightDbIdByBusinessId(res.getFlight().getFlightID());
            }
            
            if (flightId > 0) {
                // Get booked seats
                java.util.List<Integer> bookedSeats = bookingDAO.getBookedSeats(flightId);
                
                // Remove current seat from booked list if it exists
                if (res.getSeatNumber() != null) {
                    bookedSeats.remove(res.getSeatNumber());
                }
                
                // Get all available seats (1 to capacity)
                int capacity = res.getFlight().getCapacity();
                java.util.List<Integer> availableSeats = new java.util.ArrayList<>();
                
                for (int seatNum = 1; seatNum <= capacity; seatNum++) {
                    if (!bookedSeats.contains(seatNum)) {
                        availableSeats.add(seatNum);
                    }
                }
                
                // Sort seats
                java.util.Collections.sort(availableSeats);
                
                // Add to combo box
                seatComboBox.addItem(null); // Allow "No seat" option
                for (Integer seat : availableSeats) {
                    seatComboBox.addItem(seat);
                }
                
                // Select current seat if it exists
                if (res.getSeatNumber() != null) {
                    seatComboBox.setSelectedItem(res.getSeatNumber());
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(seatDialog, "Error loading seats: " + e.getMessage());
            e.printStackTrace();
        }
        
        infoPanel.add(seatComboBox);
        seatDialog.add(infoPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton saveBtn = new JButton("Save");
        JButton cancelBtn = new JButton("Cancel");
        
        saveBtn.addActionListener(e -> {
            Integer newSeat = (Integer) seatComboBox.getSelectedItem();
            
            // Update seat using CustomerService
            if (customerService != null) {
                boolean success = customerService.updateSeatNumberForBooking(bookingId, newSeat);
                if (success) {
                    JOptionPane.showMessageDialog(seatDialog, "Seat updated successfully!");
                    seatDialog.dispose();
                    parentDialog.dispose();
                    showModifyReservations(); // Refresh
                } else {
                    JOptionPane.showMessageDialog(seatDialog, 
                        "Failed to update seat. The seat may be already taken or invalid.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(seatDialog, "Service not available.");
            }
        });
        
        cancelBtn.addActionListener(e -> seatDialog.dispose());
        
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);
        seatDialog.add(buttonPanel, BorderLayout.SOUTH);
        seatDialog.setVisible(true);
    }
}
