package main.java.gui;

import main.java.model.Flight;
import main.java.model.Reservation;
import main.java.model.PaymentSystem;
import main.java.service.CustomerService;
import main.java.service.CreditCardPayment;
import main.java.service.PayPalPayment;
import main.java.dao.FlightDAO;
import main.java.dao.BookingDAO;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class BookingPanel extends JFrame {

    private CustomerService customerService;
    private Flight flight;
    private boolean isAgent;
    private String prefillUsername; // Pre-filled username for agent bookings
    private JTextField customerUsernameField; // For agent bookings
    private JComboBox<Integer> seatComboBox; // Seat selection dropdown
    private Integer selectedSeatNumber; // Selected seat number
    private FlightDAO flightDAO; // Flight DAO for seat validation
    
    // BookingPanel is written below 
    public BookingPanel(CustomerService customerService, Flight flight) {
        this(customerService, flight, false);
    }
    
    public BookingPanel(CustomerService customerService, Flight flight, boolean isAgent) {
        this(customerService, flight, isAgent, null);
    }
    
    public BookingPanel(CustomerService customerService, Flight flight, boolean isAgent, String prefillUsername) {
        this.customerService = customerService;
        this.flight = flight;
        this.isAgent = isAgent;
        this.prefillUsername = prefillUsername;
        this.flightDAO = new FlightDAO();

        setTitle("Booking Summary");
        setSize(500, 550);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== Title =====
        JLabel title = new JLabel("Confirm Your Booking", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        add(title, BorderLayout.NORTH);

        // ===== Info Panel =====
        JPanel info = new JPanel();
        int gridRows = isAgent ? 8 : 7; // Extra row for customer username if agent, plus seat selection
        info.setLayout(new GridLayout(gridRows, 1, 8, 8));
        info.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        // Create labels with proper sizing to prevent text clipping
        JLabel codeLabel = new JLabel("Flight Code: " + (flight.getFlightCode() != null ? flight.getFlightCode() : "N/A"));
        codeLabel.setPreferredSize(new Dimension(400, 25));
        info.add(codeLabel);
        
        JLabel airlineLabel = new JLabel("Airline: " + (flight.getAirLine() != null ? flight.getAirLine() : "N/A"));
        airlineLabel.setPreferredSize(new Dimension(400, 25));
        info.add(airlineLabel);
        
        String dateStr = flight.getFlightDate() != null ? flight.getFlightDate().toString() : "N/A";
        JLabel dateLabel = new JLabel("Date: " + dateStr);
        dateLabel.setPreferredSize(new Dimension(400, 25));
        info.add(dateLabel);
        
        JLabel fromLabel = new JLabel("From: " + (flight.getDepartureAreaCode() != null ? flight.getDepartureAreaCode().toString() : "N/A"));
        fromLabel.setPreferredSize(new Dimension(400, 25));
        info.add(fromLabel);
        
        JLabel toLabel = new JLabel("To: " + (flight.getArrivalAreaCode() != null ? flight.getArrivalAreaCode().toString() : "N/A"));
        toLabel.setPreferredSize(new Dimension(400, 25));
        info.add(toLabel);
        
        JLabel priceLabel = new JLabel("Price: $" + String.format("%.2f", flight.getPrice()));
        priceLabel.setPreferredSize(new Dimension(400, 25));
        info.add(priceLabel);
        
        // Seat Selection
        info.add(new JLabel("Select Seat:"));
        seatComboBox = new JComboBox<>();
        seatComboBox.addActionListener(e -> {
            if (seatComboBox.getSelectedItem() != null) {
                selectedSeatNumber = (Integer) seatComboBox.getSelectedItem();
            }
        });
        loadAvailableSeats(); // Load after combo box is created
        info.add(seatComboBox);
        
        // Agent-specific: Customer username field
        if (isAgent) {
            info.add(new JLabel("Customer Username:"));
            customerUsernameField = new JTextField();
            // Pre-fill username if provided (for agent bookings from customer search)
            if (prefillUsername != null) {
                customerUsernameField.setText(prefillUsername);
            }
            info.add(customerUsernameField);
        }

        add(info, BorderLayout.CENTER);

        // ===== Buttons =====
        JPanel bottom = new JPanel();

        JButton confirmBtn = new JButton("Confirm & Pay");
        JButton backBtn = new JButton("Back");

        confirmBtn.addActionListener(e -> {
            // Validate seat selection
            if (selectedSeatNumber == null) {
                JOptionPane.showMessageDialog(this, "Please select a seat.");
                return;
            }
            
            Reservation r = null;
            
            if (isAgent) {
                // Agent booking for a customer
                String customerUsername = customerUsernameField.getText().trim();
                if (customerUsername.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter customer username.");
                    return;
                }
                
                r = customerService.makeReservationForCustomer(flight.getFlightID(), customerUsername, selectedSeatNumber);
                if (r == null) {
                    // Check if it's a seat conflict
                    try {
                        BookingDAO bookingDAO = new BookingDAO();
                        int flightId = flight.getId();
                        if (flightId <= 0) {
                            flightId = flightDAO.findFlightDbIdByBusinessId(flight.getFlightID());
                        }
                        if (flightId > 0) {
                            List<Integer> bookedSeats = bookingDAO.getBookedSeats(flightId);
                            if (bookedSeats.contains(selectedSeatNumber)) {
                                JOptionPane.showMessageDialog(this, 
                                    "Booking failed. Seat " + selectedSeatNumber + " is already taken.\nPlease select a different seat.",
                                    "Seat Already Booked",
                                    JOptionPane.ERROR_MESSAGE);
                                // Reload available seats to refresh the list
                                loadAvailableSeats();
                                return;
                            }
                        }
                    } catch (SQLException sqlEx) {
                        // Ignore, show generic error
                    }
                    JOptionPane.showMessageDialog(this, "Booking failed. Customer username not found or invalid.");
                    return;
                }
            } else {
                // Regular customer booking
                if (customerService.getLoggedInCustomer() == null) {
                    JOptionPane.showMessageDialog(this, "Please login to make a booking.");
                    return;
                }

                r = customerService.makeReservation(flight.getFlightID(), selectedSeatNumber);

                if (r == null) {
                    // Check if it's a seat conflict
                    try {
                        BookingDAO bookingDAO = new BookingDAO();
                        int flightId = flight.getId();
                        if (flightId <= 0) {
                            flightId = flightDAO.findFlightDbIdByBusinessId(flight.getFlightID());
                        }
                        if (flightId > 0) {
                            List<Integer> bookedSeats = bookingDAO.getBookedSeats(flightId);
                            if (bookedSeats.contains(selectedSeatNumber)) {
                                JOptionPane.showMessageDialog(this, 
                                    "Booking failed. Seat " + selectedSeatNumber + " is already taken.\nPlease select a different seat.",
                                    "Seat Already Booked",
                                    JOptionPane.ERROR_MESSAGE);
                                // Reload available seats to refresh the list
                                loadAvailableSeats();
                                return;
                            }
                        }
                    } catch (SQLException sqlEx) {
                        // Ignore, show generic error
                    }
                    JOptionPane.showMessageDialog(this, "Booking failed. Please try again.");
                    return;
                }
            }

            PaymentSystem payment = new PaymentSystem();

            String[] methods = {"Credit Card", "PayPal"};
            String choice = (String) JOptionPane.showInputDialog(
                    this,
                    "Select Payment Method:",
                    "Payment",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    methods,
                    methods[0]
            );

            if (choice == null) return;

            // Get the customer for payment (either logged in customer or customer from username)
            main.java.model.Customer customerForPayment = isAgent ? 
                customerService.getCustomerByUsername(customerUsernameField.getText().trim()) :
                customerService.getLoggedInCustomer();
            
            if (customerForPayment == null) {
                JOptionPane.showMessageDialog(this, "Customer not found for payment.");
                return;
            }
            
            boolean paymentSuccess = false;
            if (choice.equals("Credit Card")) {
                String cardNumber = JOptionPane.showInputDialog(this, "Enter card number (12 digits):");
                if (cardNumber != null && !cardNumber.trim().isEmpty()) {
                    // Validate credit card: must be exactly 12 digits
                    String cardNumberTrimmed = cardNumber.trim();
                    if (!cardNumberTrimmed.matches("\\d{12}")) {
                        JOptionPane.showMessageDialog(this, 
                            "Error: Credit card number must be exactly 12 digits.\n" +
                            "Please enter a valid 12-digit card number.",
                            "Invalid Card Number",
                            JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    payment.setPaymentStrategy(new CreditCardPayment(cardNumberTrimmed, customerForPayment));
                    paymentSuccess = payment.pay(customerForPayment, flight.getPrice());
                }
            } else {
                String email = JOptionPane.showInputDialog(this, "Enter PayPal email:");
                if (email != null && !email.trim().isEmpty()) {
                    // Validate PayPal email: must contain @ symbol
                    String emailTrimmed = email.trim();
                    if (!emailTrimmed.contains("@")) {
                        JOptionPane.showMessageDialog(this, 
                            "Error: PayPal email must contain an @ symbol.\n" +
                            "Please enter a valid email address.",
                            "Invalid Email",
                            JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    payment.setPaymentStrategy(new PayPalPayment(customerForPayment, emailTrimmed));
                    paymentSuccess = payment.pay(customerForPayment, flight.getPrice());
                }
            }

            if (paymentSuccess) {
                JOptionPane.showMessageDialog(this, 
                    "Booking Confirmed!\nReservation ID: " + r.getReservationID() + 
                    "\nSeat Number: " + selectedSeatNumber);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Payment failed. Please try again.");
            }
        });

        backBtn.addActionListener(e -> {
            new FlightManagementPanel(customerService, flight).setVisible(true);
            dispose();
        });

        bottom.add(confirmBtn);
        bottom.add(backBtn);

        add(bottom, BorderLayout.SOUTH);
    }
    
    /**
     * Loads available seats for the flight into the seat selection dropdown
     */
    private void loadAvailableSeats() {
        try {
            BookingDAO bookingDAO = new BookingDAO();
            
            int flightId = flight.getId();
            if (flightId <= 0) {
                // Try to find flight ID by flight ID string
                flightId = flightDAO.findFlightDbIdByBusinessId(flight.getFlightID());
            }
            
            if (flightId <= 0) {
                JOptionPane.showMessageDialog(this, "Error: Could not find flight in database.");
                return;
            }
            
            // Get booked seats
            List<Integer> bookedSeats = bookingDAO.getBookedSeats(flightId);
            
            // Get all available seats (1 to capacity)
            int capacity = flight.getCapacity();
            List<Integer> availableSeats = new ArrayList<>();
            
            for (int seatNum = 1; seatNum <= capacity; seatNum++) {
                if (!bookedSeats.contains(seatNum)) {
                    availableSeats.add(seatNum);
                }
            }
            
            // Sort seats
            Collections.sort(availableSeats);
            
            // Add to combo box
            seatComboBox.removeAllItems();
            if (availableSeats.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "No seats available for this flight.",
                    "No Seats Available",
                    JOptionPane.WARNING_MESSAGE);
                seatComboBox.setEnabled(false);
            } else {
                for (Integer seat : availableSeats) {
                    seatComboBox.addItem(seat);
                }
                // Select first available seat by default
                if (seatComboBox.getItemCount() > 0) {
                    seatComboBox.setSelectedIndex(0);
                    selectedSeatNumber = (Integer) seatComboBox.getSelectedItem();
                }
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading available seats: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            seatComboBox.setEnabled(false);
        }
    }
}
