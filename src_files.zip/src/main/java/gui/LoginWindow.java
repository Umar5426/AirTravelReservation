package main.java.gui;

import java.awt.*;
import javax.swing.*;
import main.java.service.CustomerService;
import main.java.dao.AuthorizationDAO;

/**
 * Login Window
 * 
 * DESIGN PATTERNS:
 * 1. DAO Pattern - All authentication through DAO layer (no hardcoded credentials)
 * 2. Separation of Concerns - GUI only handles UI, delegates business logic to services
 */
public class LoginWindow extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;

    // DESIGN PATTERN: DAO Pattern - Authentication through DAO
    private CustomerService customerService = new CustomerService();
    private AuthorizationDAO authDAO = new AuthorizationDAO();

    public LoginWindow() {
        setTitle("Flight Reservation System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Title 
        JLabel titleLabel = new JLabel("Login", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(titleLabel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setPreferredSize(new Dimension(100, 25));
        formPanel.add(usernameLabel);
        usernameField = new JTextField();
        usernameField.setPreferredSize(new Dimension(200, 25));
        formPanel.add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setPreferredSize(new Dimension(100, 25));
        formPanel.add(passwordLabel);
        passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(200, 25));
        formPanel.add(passwordField);

        add(formPanel, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");
        JButton guestBtn = new JButton("Continue as Guest");

        buttonPanel.add(loginBtn);
        buttonPanel.add(registerBtn);
        buttonPanel.add(guestBtn);

        add(buttonPanel, BorderLayout.SOUTH);

        // ===== Event Listeners =====

        loginBtn.addActionListener(e -> {
            String user = usernameField.getText();
            String pass = new String(passwordField.getPassword());
            attemptLogin(user, pass);
        });

        registerBtn.addActionListener(e -> showRegistrationDialog());

        guestBtn.addActionListener(e -> continueAsGuest());
    }

    // =============================
    //   Methods Called on Actions
    // =============================

    /**
     * Attempts to authenticate user
     * DESIGN PATTERN: DAO Pattern - All authentication through database (no hardcoded credentials)
     */
    private void attemptLogin(String username, String password) {
        System.out.println("Attempting login: " + username);
        
        try {
            // DESIGN PATTERN: DAO Pattern - All authentication through database
            // No hardcoded credentials - "Captain"/"Abdul4" now in database
            String role = authDAO.login(username, password);
            
            if (role != null) {
                if (role.equals("ADMIN")) {
                    JOptionPane.showMessageDialog(this, "Admin Login Successful!");
                    new AdminWindow().setVisible(true);
                    dispose();
                    return;
                } else if (role.equals("AGENT")) {
                    JOptionPane.showMessageDialog(this, "Flight Agent Login Successful!");
                    // Create MainWindow with isAgent=true directly
                    MainWindow agentWindow = new MainWindow(false, true);
                    agentWindow.setVisible(true);
                    dispose();
                    return;
                }
            }
            
            // Check for Customer login
            boolean authenticated = customerService.login(username, password);

            if (authenticated) {
                JOptionPane.showMessageDialog(this, "Login Successful!");
                
                // Show monthly promotion on every customer login
                showMonthlyPromotion();
                
                // Pass the same customerService instance to MainWindow so login state is preserved
                MainWindow mainWindow = new MainWindow(false);
                mainWindow.setCustomerService(customerService); // Set the logged-in service
                mainWindow.setVisible(true);
                dispose();
                return;
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Login error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Shows monthly promotion dialog to customers on login
     */
    private void showMonthlyPromotion() {
        java.time.LocalDate today = java.time.LocalDate.now();
        java.time.YearMonth currentMonth = java.time.YearMonth.from(today);
        String monthName = currentMonth.getMonth().toString();
        monthName = monthName.charAt(0) + monthName.substring(1).toLowerCase();
        
        javax.swing.JDialog dialog = new javax.swing.JDialog(this, "Monthly Promotion", true);
        dialog.setSize(450, 200);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new java.awt.BorderLayout());
        
        javax.swing.JPanel panel = new javax.swing.JPanel();
        panel.setLayout(new java.awt.BorderLayout());
        panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        javax.swing.JLabel messageLabel = new javax.swing.JLabel(
            "<html><body style='text-align: center; padding: 10px;'>" +
            "🎉 <b>Monthly Promotion Alert!</b> 🎉<br><br>" +
            "Check out our special deals for " + monthName + "!<br>" +
            "Don't miss out on exclusive flight discounts!" +
            "</body></html>"
        );
        messageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        messageLabel.setPreferredSize(new java.awt.Dimension(400, 120));
        
        panel.add(messageLabel, java.awt.BorderLayout.CENTER);
        
        javax.swing.JButton okButton = new javax.swing.JButton("OK");
        okButton.addActionListener(e -> dialog.dispose());
        javax.swing.JPanel buttonPanel = new javax.swing.JPanel(new java.awt.FlowLayout());
        buttonPanel.add(okButton);
        
        dialog.add(panel, java.awt.BorderLayout.CENTER);
        dialog.add(buttonPanel, java.awt.BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void continueAsGuest() {
        System.out.println("Continuing as Guest...");
        new MainWindow(true).setVisible(true);
        dispose();
    }

    /**
     * Shows registration dialog for new customer signup
     * DESIGN PATTERN: DAO Pattern - Registration through service/DAO layer
     */
    private void showRegistrationDialog() {
        JDialog registerDialog = new JDialog(this, "Register New Customer", true);
        registerDialog.setSize(450, 450);
        registerDialog.setLocationRelativeTo(this);
        registerDialog.setLayout(new BorderLayout());

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(9, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField dobField = new JTextField(); // Format: YYYY-MM-DD
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JPasswordField confirmPasswordField = new JPasswordField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();

        formPanel.add(new JLabel("First Name:"));
        formPanel.add(firstNameField);
        formPanel.add(new JLabel("Last Name:"));
        formPanel.add(lastNameField);
        formPanel.add(new JLabel("Date of Birth (YYYY-MM-DD):"));
        formPanel.add(dobField);
        formPanel.add(new JLabel("Username:"));
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Password:"));
        formPanel.add(passwordField);
        formPanel.add(new JLabel("Confirm Password:"));
        formPanel.add(confirmPasswordField);
        formPanel.add(new JLabel("Email (optional):"));
        formPanel.add(emailField);
        formPanel.add(new JLabel("Phone (optional):"));
        formPanel.add(phoneField);

        registerDialog.add(formPanel, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton submitBtn = new JButton("Register");
        JButton cancelBtn = new JButton("Cancel");

        submitBtn.addActionListener(e -> {
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String dobStr = dobField.getText().trim();
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();

            // Validation
            if (firstName.isEmpty() || lastName.isEmpty() || 
                username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(registerDialog, 
                    "Please fill in all required fields (First Name, Last Name, Username, Password).");
                return;
            }

            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(registerDialog, "Passwords do not match!");
                return;
            }

            // Parse date of birth
            java.util.Date dob = null;
            if (!dobStr.isEmpty()) {
                try {
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                    dob = sdf.parse(dobStr);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(registerDialog, 
                        "Invalid date format. Please use YYYY-MM-DD format.");
                    return;
                }
            }

            // Use empty strings for optional fields if not provided
            if (email.isEmpty()) email = null;
            if (phone.isEmpty()) phone = null;

            // Register customer (customer ID is auto-generated, hidden from user)
            boolean success = customerService.register(firstName, lastName, 
                                                      dob, username, password, email, phone);

            if (success) {
                JOptionPane.showMessageDialog(registerDialog, 
                    "Registration successful! You can now login.");
                registerDialog.dispose();
            } else {
                JOptionPane.showMessageDialog(registerDialog, 
                    "Registration failed. Username may already be taken.");
            }
        });

        cancelBtn.addActionListener(e -> registerDialog.dispose());

        buttonPanel.add(submitBtn);
        buttonPanel.add(cancelBtn);
        registerDialog.add(buttonPanel, BorderLayout.SOUTH);

        registerDialog.setVisible(true);
    }
}
