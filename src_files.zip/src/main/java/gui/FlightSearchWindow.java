package main.java.gui;

import main.java.model.Flight;
import main.java.service.CustomerService;
import main.java.dao.FlightDAO;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Flight Search Window
 * 
 * DESIGN PATTERNS:
 * 1. DAO Pattern - Uses FlightDAO directly for search operations
 * 2. Separation of Concerns - GUI only handles UI, delegates to DAO
 */
public class FlightSearchWindow extends JFrame {

    private JTextField fromField;
    private JTextField toField;
    private JTextField dateField;

    private CustomerService customerService;
    private FlightDAO flightDAO;
    private boolean isGuest;
    private String prefillCustomerUsername; // For agent bookings

    public FlightSearchWindow(boolean isGuest) {
        this(isGuest, new CustomerService());
    }

    public FlightSearchWindow(boolean isGuest, CustomerService customerService) {
        this.customerService = customerService;
        this.flightDAO = new FlightDAO();
        this.isGuest = isGuest;
        
        // Update isGuest flag based on whether customer is logged in
        if (customerService.getLoggedInCustomer() != null) {
            this.isGuest = false;
        }

        setTitle("Search Flights");
        setSize(500, 350);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // =======================
        // Title
        // =======================
        JLabel title = new JLabel("Search Available Flights", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        // =======================
        // Search Form
        // =======================
        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel fromLabel = new JLabel("From (Area Code):");
        fromLabel.setPreferredSize(new Dimension(150, 25));
        form.add(fromLabel);
        fromField = new JTextField();
        fromField.setPreferredSize(new Dimension(200, 25));
        form.add(fromField);

        JLabel toLabel = new JLabel("To (Area Code):");
        toLabel.setPreferredSize(new Dimension(150, 25));
        form.add(toLabel);
        toField = new JTextField();
        toField.setPreferredSize(new Dimension(200, 25));
        form.add(toField);

        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateLabel.setPreferredSize(new Dimension(150, 25));
        form.add(dateLabel);
        dateField = new JTextField();
        dateField.setPreferredSize(new Dimension(200, 25));
        form.add(dateField);

        add(form, BorderLayout.CENTER);

        // =======================
        // Buttons
        // =======================
        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton searchBtn = new JButton("Search");
        JButton backBtn = new JButton("Back");

        buttonPanel.add(searchBtn);
        buttonPanel.add(backBtn);

        add(buttonPanel, BorderLayout.SOUTH);

        // =======================
        // Action Listeners
        // =======================
        searchBtn.addActionListener(e -> searchFlights());
        backBtn.addActionListener(e -> goBack());

        // =======================
        // X Button Behavior
        // =======================
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                goBack();
            }
        });
    }

    private void searchFlights() {
        String from = fromField.getText().trim();
        String to = toField.getText().trim();
        String date = dateField.getText().trim();

        if (from.isEmpty() || to.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter both departure and arrival area codes.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Search for flights and get Flight objects (with date filter if provided)
            String dateFilter = date.isEmpty() ? null : date;
            List<Flight> flightResults = flightDAO.searchFlightsAsObjects(from, to, dateFilter);
            
            if (flightResults.isEmpty()) {
                String dateMsg = (!date.isEmpty()) ? "\n- Date matches: " + date : "";
                JOptionPane.showMessageDialog(this,
                        "No flights found for the selected criteria.\n\n" +
                        "Please check:\n" +
                        "- Area codes are correct (e.g., YYC, YVR, YYZ)\n" +
                        "- Route exists in the system" + dateMsg,
                        "No Results",
                        JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Show results in a table dialog with booking option
                showFlightResults(flightResults);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error searching flights: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    /**
     * Shows flight search results in a table with booking option
     */
    private void showFlightResults(List<Flight> flights) {
        JDialog resultsDialog = new JDialog(this, "Search Results", true);
        resultsDialog.setSize(800, 500);
        resultsDialog.setLocationRelativeTo(this);
        resultsDialog.setLayout(new BorderLayout());
        
        // Create table
        String[] columns = {"Flight Code", "Airline", "Date", "From", "To", "Duration", "Price", "Available Seats", "Action"};
        javax.swing.table.DefaultTableModel model = new javax.swing.table.DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable table = new JTable(model);
        table.setRowHeight(30);
        
        // Add flights to table
        for (Flight flight : flights) {
            String dateStr = "N/A";
            if (flight.getFlightDate() != null) {
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                dateStr = sdf.format(flight.getFlightDate());
            }
            
            // Calculate available seats
            int availableSeats = 0;
            String availableSeatsStr = "N/A";
            try {
                int flightId = flight.getId();
                if (flightId > 0) {
                    availableSeats = flightDAO.getAvailableSeats(flightId);
                    availableSeatsStr = availableSeats + " / " + flight.getCapacity();
                } else {
                    // If ID is not set, show capacity as available (new flight)
                    availableSeats = flight.getCapacity();
                    availableSeatsStr = availableSeats + " / " + flight.getCapacity();
                }
            } catch (SQLException e) {
                // If error occurs, show capacity as fallback
                System.err.println("Error getting available seats for flight " + flight.getFlightCode() + ": " + e.getMessage());
                e.printStackTrace();
                availableSeats = flight.getCapacity();
                availableSeatsStr = availableSeats + " / " + flight.getCapacity();
            }
            
            Object[] row = {
                flight.getFlightCode(),
                flight.getAirLine(),
                dateStr,
                flight.getDepartureAreaCode() != null ? flight.getDepartureAreaCode().toString() : "N/A",
                flight.getArrivalAreaCode() != null ? flight.getArrivalAreaCode().toString() : "N/A",
                flight.getFlightDuration() != null ? flight.getFlightDuration() : "N/A",
                "$" + String.format("%.2f", flight.getPrice()),
                availableSeatsStr,  // Available Seats column
                "Book"
            };
            model.addRow(row);
        }
        
        JScrollPane scrollPane = new JScrollPane(table);
        resultsDialog.add(scrollPane, BorderLayout.CENTER);
        
        // Set column widths to ensure "Available Seats" column is visible (after table is populated)
        if (table.getColumnCount() > 7) {
            table.getColumnModel().getColumn(7).setPreferredWidth(130); // Available Seats column
        }
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton bookBtn = new JButton("Book Selected Flight");
        JButton closeBtn = new JButton("Close");
        
        bookBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(resultsDialog, "Please select a flight to book.");
                return;
            }
            
            Flight selectedFlight = flights.get(selectedRow);
            resultsDialog.dispose();
            
            if (isGuest || customerService.getLoggedInCustomer() == null) {
                JOptionPane.showMessageDialog(this,
                    "Please login or register to book flights.",
                    "Login Required",
                    JOptionPane.INFORMATION_MESSAGE);
                new LoginWindow().setVisible(true);
                dispose();
            } else {
                // For agents booking for a specific customer, open BookingPanel directly with username pre-filled
                if (prefillCustomerUsername != null && !prefillCustomerUsername.isEmpty()) {
                    new BookingPanel(customerService, selectedFlight, true, prefillCustomerUsername).setVisible(true);
                } else {
                    new FlightManagementPanel(customerService, selectedFlight).setVisible(true);
                }
            }
        });
        
        closeBtn.addActionListener(e -> resultsDialog.dispose());
        
        buttonPanel.add(bookBtn);
        buttonPanel.add(closeBtn);
        resultsDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        resultsDialog.setVisible(true);
    }

    /**
     * Sets the customer username to pre-fill when booking (for agents)
     */
    public void setCustomerUsernameForBooking(String username) {
        this.prefillCustomerUsername = username;
    }
    
    private void goBack() {
        MainWindow mainWindow = new MainWindow(isGuest);
        mainWindow.setCustomerService(customerService); // Preserve login state
        mainWindow.setVisible(true);
        dispose();
    }
}
