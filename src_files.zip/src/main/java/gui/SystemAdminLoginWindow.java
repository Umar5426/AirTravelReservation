package main.java.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.*;

public class SystemAdminLoginWindow extends JFrame {
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    
    public SystemAdminLoginWindow() {
        setTitle("System Admin Login");
        setSize(410, 260);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Title
        JLabel title = new JLabel("System Administrator Login", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        add(title, BorderLayout.NORTH);

        // Form
        JPanel form = new JPanel(new GridLayout(2, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        form.add(new JLabel("Username:"));
        usernameField = new JTextField();
        form.add(usernameField);

        form.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        form.add(passwordField); 
        
        add(form, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout());
        JButton loginBtn = new JButton("Login");
        JButton cancelBtn = new JButton("Cancel");
        btnPanel.add(loginBtn);
        btnPanel.add(cancelBtn);
        add(btnPanel, BorderLayout.SOUTH);

        // Listeners
        loginBtn.addActionListener(e -> verifyLogin());
        cancelBtn.addActionListener(e -> dispose());
    }

    /**
     * Verifies admin login
     * DESIGN PATTERN: DAO Pattern - All authentication through database
     * No hardcoded credentials - "Captain"/"Abdul4" now in database
     */
    private void verifyLogin() {
        String user = usernameField.getText();
        String pass = new String(passwordField.getPassword());

        try {
            // DESIGN PATTERN: DAO Pattern - Check database, not hardcoded values
            main.java.dao.AuthorizationDAO authDAO = new main.java.dao.AuthorizationDAO();
            String role = authDAO.login(user, pass);
        
            if (role != null && role.equals("ADMIN")) {
            JOptionPane.showMessageDialog(this, "Login Successful!");
            new AdminWindow().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Login error: " + e.getMessage());
        }
    }

    
}
