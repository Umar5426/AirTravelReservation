package main.java.gui;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import main.java.model.Flight;
import main.java.service.CustomerService;

public class FlightManagementPanel extends JFrame {
    private CustomerService customerService;
    private Flight flight;
    private boolean isAgent;

    public FlightManagementPanel(CustomerService customerService, Flight flight) {
        this(customerService, flight, false);
    }
    
    public FlightManagementPanel(CustomerService customerService, Flight flight, boolean isAgent) {
        this.customerService = customerService;
        this.flight = flight;
        this.isAgent = isAgent;

        setTitle("Flight Details");
        setSize(510, 460);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Title is here
        JLabel title = new JLabel("Flight Details", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        add(title, BorderLayout.NORTH);

        // Information Panel
        JPanel info = new JPanel();
        info.setLayout(new GridLayout(7, 1, 8, 8));
        info.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        // Create labels with proper sizing to prevent text clipping
        JLabel codeLabel = new JLabel("Flight Code: " + (flight.getFlightCode() != null ? flight.getFlightCode() : "N/A"));
        codeLabel.setPreferredSize(new Dimension(400, 25));
        info.add(codeLabel);
        
        JLabel airlineLabel = new JLabel("Airline: " + (flight.getAirLine() != null ? flight.getAirLine() : "N/A"));
        airlineLabel.setPreferredSize(new Dimension(400, 25));
        info.add(airlineLabel);
        
        String dateStr = flight.getFlightDate() != null ? flight.getFlightDate().toString() : "N/A";
        JLabel dateLabel = new JLabel("Date: " + dateStr);
        dateLabel.setPreferredSize(new Dimension(400, 25));
        info.add(dateLabel);
        
        JLabel durationLabel = new JLabel("Duration: " + (flight.getFlightDuration() != null ? flight.getFlightDuration() : "N/A"));
        durationLabel.setPreferredSize(new Dimension(400, 25));
        info.add(durationLabel);
        
        JLabel fromLabel = new JLabel("From: " + (flight.getDepartureAreaCode() != null ? flight.getDepartureAreaCode().toString() : "N/A"));
        fromLabel.setPreferredSize(new Dimension(400, 25));
        info.add(fromLabel);
        
        JLabel toLabel = new JLabel("To: " + (flight.getArrivalAreaCode() != null ? flight.getArrivalAreaCode().toString() : "N/A"));
        toLabel.setPreferredSize(new Dimension(400, 25));
        info.add(toLabel);
        
        JLabel priceLabel = new JLabel("Price: $" + String.format("%.2f", flight.getPrice()));
        priceLabel.setPreferredSize(new Dimension(400, 25));
        info.add(priceLabel);

        add(info, BorderLayout.CENTER);

        // ===== Buttons =====
        JPanel bottom = new JPanel();

        JButton bookBtn = new JButton("Book Flight");
        JButton backBtn = new JButton("Back");

        bookBtn.addActionListener(e -> {
            new BookingPanel(customerService, flight, isAgent).setVisible(true);
            dispose();
        });

        backBtn.addActionListener(e -> dispose());

        bottom.add(bookBtn);
        bottom.add(backBtn);

        add(bottom, BorderLayout.SOUTH);
    }

    
}
