package main.java.model;

import java.util.Date;

public class Reservation {

    private String reservationID;
    private int bookingDbId = -1;
    private Customer customer;
    private Date dateBooked;
    private Flight flight;
    private double totalPrice;
    private Integer seatNumber;

    // -----------------------
    // Constructor for new reservations (before saving to DB)
    // -----------------------
    public Reservation(Customer customer, Flight flight) {
        this.customer = customer;
        this.flight = flight;
        this.dateBooked = new Date();         // today's date
        // Reservation ID will be set when booking is saved to database
        this.reservationID = null;
    }
    
    // -----------------------
    // Constructor for existing reservations (from database)
    // -----------------------
    public Reservation(int bookingDbId, Customer customer, Flight flight, Date dateBooked, double totalPrice) {
        this.bookingDbId = bookingDbId;
        this.reservationID = "R" + bookingDbId;  // Use booking ID as reservation ID
        this.customer = customer;
        this.flight = flight;
        this.dateBooked = dateBooked;
        this.totalPrice = totalPrice;
    }

    // -----------------------
    // Getters / Setters 
    // -----------------------
    public String getReservationID() {
        return reservationID;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Date getDateBooked() {
        return dateBooked;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public int getBookingDbId() {
        return bookingDbId;
    }

    public void setBookingDbId(int bookingDbId) {
        this.bookingDbId = bookingDbId;
        // Update reservation ID when booking ID is set
        if (this.reservationID == null && bookingDbId > 0) {
            this.reservationID = "R" + bookingDbId;
        }
    }

    public void setDateBooked(Date dateBooked) {
        this.dateBooked = dateBooked;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Integer getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(Integer seatNumber) {
        this.seatNumber = seatNumber;
    }
}
