package main.java.model;
import java.util.List;
import main.java.service.FlightService;

/**
 * System Administrator
 * 
 * DESIGN PATTERNS:
 * 1. DAO Pattern - All flight management through FlightService which uses DAO
 * 2. Single Responsibility - Handles admin-specific operations
 */
public class SystemAdministrator {

    // Fields are set below
    private boolean loggedIn = false;
    private Customer loggedCustomer;
    private FlightService flightService;

    /**
     * Constructor
     * DESIGN PATTERN: DAO Pattern - FlightService uses DAO for all operations
     */
    public SystemAdministrator() {
        flightService = new FlightService();
    }
    
    // Login
    public boolean login(String username, String password, List<Customer> customers) {

    for (Customer c : customers) {
        if (c.getUsername().equals(username) && c.getPassword().equals(password)) {
            this.loggedIn = true;
            this.loggedCustomer = c;

            System.out.println("Login is successful! You are Welcome, " 
                               + c.getFname() + " " + c.getLname());
            return true;
        }
    }

    System.out.println("Invalid username or password.");
    return false;
}

	
    // Admin Functions
    /**
     * Adds a flight using FlightService (which uses DAO)
     * DESIGN PATTERN: DAO Pattern - All operations through service/DAO layer
     */
    public void addFlight(Flight flight) {
        flightService.addFlight(flight);
        System.out.println("Flight has been added successfully");
    }

    /**
     * Updates a flight using FlightService (which uses DAO)
     * DESIGN PATTERN: DAO Pattern
     */
    public void updateFlight(String flightID, Flight updatedFlight) {
        flightService.updateFlight(flightID, updatedFlight); 
        System.out.println("Flight has been updated.");
    }

    /**
     * Deletes a flight using FlightService (which uses DAO)
     * DESIGN PATTERN: DAO Pattern
     */
    public void deleteFlight(String flightID) {
        flightService.deleteFlight(flightID);
        System.out.println("Flight has been deleted successfully.");
    }

    public List<Flight> viewFlightSchedule() {
        // getting the flights from the service below
		List<Flight> schedule = flightService.getAllFlights();
		
		// printing each flight
		for (Flight f : schedule) {
			System.out.println(f.getFlightCode() + " on " + f.getFlightDate());
		}
		return schedule;
	} 
     
    
}
