package main.java.model;

/**
 * Subject Interface
 * 
 * DESIGN PATTERN: Observer Pattern
 * - Defines the contract for objects that maintain a list of observers
 * - Part of the Observer pattern along with Observer interface
 * - Enables one-to-many dependency between objects
 * - When subject's state changes, all observers are notified
 * 
 * WHY OBSERVER?
 * - TimerSystem (Subject) notifies multiple observers (NotificationsService, etc.)
 * - Observers can register/unregister dynamically
 * - Loose coupling - Subject doesn't know concrete observer types
 */
public interface Subject {
    /**
     * Registers an observer to receive notifications
     * DESIGN PATTERN: Observer Pattern
     * 
     * @param observer the observer to register
     */
    void register(Observer observer);
    
    /**
     * Unregisters an observer from receiving notifications
     * DESIGN PATTERN: Observer Pattern
     * 
     * @param observer the observer to unregister
     */
    void unregister(Observer observer);
}
