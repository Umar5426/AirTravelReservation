package main.java.model;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Vector;

/**
 * Timer System
 * 
 * DESIGN PATTERN: Observer Pattern - Subject
 * - Implements Subject interface
 * - Maintains list of observers and notifies them when monthly promotion event occurs
 * - Represents the external Timer/Clock actor in the use-case diagram
 * - When the 1st day of the month happens, TimerSystem notifies all registered observers
 * 
 * WHY OBSERVER?
 * - Multiple components need to react to monthly promotion (GUI, database, notifications)
 * - Decouples event source (TimerSystem) from event handlers (observers)
 * - Observers can be added/removed without modifying TimerSystem
 * - Follows Open/Closed Principle - can add new observers without changing TimerSystem
 *
 * IMPORTANT:
 * TimerSystem does NOT do any GUI code or DB code.
 * It only triggers notifications by calling update(...) on observers.
 * This follows Single Responsibility Principle.
 */
public class TimerSystem implements Subject {


    private final Vector observers;

    /*
     * Prevent sending multiple notifications in the same month.
     * Even if GUI calls checkAndNotify(...) many times, we only notify once per month.
     */
    private YearMonth lastNotifiedMonth;

    public TimerSystem() {
        observers = new Vector();
        lastNotifiedMonth = null;
    }

    /**
     * Registers an observer to receive monthly promotion notifications
     * DESIGN PATTERN: Observer Pattern
     */
    @Override
    public void register(Observer observer) {
        if (observer == null) return;
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }

    /**
     * Unregisters an observer from receiving notifications
     * DESIGN PATTERN: Observer Pattern
     */
    @Override
    public void unregister(Observer observer) {
        observers.remove(observer);
    }

    /*
     * The GUI (or app startup) can call this daily, hourly, or on startup.
     * If today is day 1, we trigger the monthly promotion event.
     */
    public void checkAndNotify(LocalDate today) {
        if (today == null) return;

        if (today.getDayOfMonth() != 1) {
            return;
        }

        YearMonth currentMonth = YearMonth.from(today);

        if (lastNotifiedMonth != null && lastNotifiedMonth.equals(currentMonth)) {
            return;
        }

        lastNotifiedMonth = currentMonth;

        MonthlyPromotionEvent event = new MonthlyPromotionEvent(today, currentMonth);
        notifyObservers(event);
    }

    /**
     * Notifies all registered observers of the monthly promotion event
     * DESIGN PATTERN: Observer Pattern - Notification mechanism
     * 
     * TimerSystem does not decide what happens next - that's the observer's responsibility.
     * Observers can:
     *  - write to DB (CRUD)
     *  - update GUI
     *  - create notifications, etc.
     * 
     * This follows the Observer pattern's principle of loose coupling.
     */
    private void notifyObservers(MonthlyPromotionEvent event) {
        for (int i = 0; i < observers.size(); i++) {
            Observer obs = (Observer) observers.get(i);
            obs.update(event);
        }
    }
}

