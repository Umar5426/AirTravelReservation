package main.java.model;

/**
 * Observer Interface
 * 
 * DESIGN PATTERN: Observer Pattern
 * - Defines the contract for objects that should be notified of state changes
 * - Part of the Observer pattern along with Subject interface
 * - Enables loose coupling between subject and observers
 * - Follows Dependency Inversion - depends on abstraction, not concrete implementations
 * 
 * WHY OBSERVER?
 * - Monthly promotion system needs to notify multiple components (GUI, database, etc.)
 * - Observers can be added/removed without modifying the Subject (TimerSystem)
 * - Decouples the event source from event handlers
 */
public interface Observer {
    /**
     * Called when the subject's state changes
     * DESIGN PATTERN: Observer Pattern - Update method
     * 
     * @param event the event that triggered the notification
     */
    void update(MonthlyPromotionEvent event);
}

