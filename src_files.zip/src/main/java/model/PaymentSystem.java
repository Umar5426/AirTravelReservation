package main.java.model;

/**
 * Payment System
 * 
 * DESIGN PATTERN: Strategy Pattern
 * - Encapsulates payment algorithms (CreditCard, PayPal) as interchangeable strategies
 * - Context (PaymentSystem) delegates payment execution to strategy
 * - Follows Open/Closed Principle - can add new payment methods without modifying existing code
 * - Follows Dependency Inversion - depends on PaymentStrategy interface, not concrete implementations
 */
public class PaymentSystem {
    // DESIGN PATTERN: Strategy Pattern
    // PaymentStrategy is the strategy interface
    // CreditCardPayment and PayPalPayment are concrete strategies
    private main.java.service.PaymentStrategy paymentStrategy;

    /**
     * Sets the payment strategy to use
     * DESIGN PATTERN: Strategy Pattern - Strategy can be changed at runtime
     */
    public void setPaymentStrategy(main.java.service.PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    /**
     * Executes payment using the current strategy
     * DESIGN PATTERN: Strategy Pattern - Delegates to strategy
     */
    public boolean pay(Customer cardHolder, double amount) {
        if (paymentStrategy == null) {
            System.out.println("No payment method selected!");
            return false;
        }

        // DESIGN PATTERN: Strategy Pattern
        // Delegates payment execution to the selected strategy
        return paymentStrategy.pay(cardHolder, amount);
    }
}
