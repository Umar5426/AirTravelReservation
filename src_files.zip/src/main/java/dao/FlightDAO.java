package main.java.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import main.java.model.AreaCode;
import main.java.model.Flight;
import main.java.dao.BookingDAO;

public class FlightDAO extends BaseDAO {

    /**
     * Adds a new flight to the database
     * @param capacity The total number of seats on the flight (all seats are available initially)
     * Note: When a new flight is created, all seats are available (available = capacity)
     */
    public void addFlight(String flightId,
                          String flightCode,
                          String airline,
                          java.util.Date flightDate,
                          String flightDuration,
                          String departureAreaCode,
                          String arrivalAreaCode,
                          int capacity,
                          double price) throws SQLException {

        String sql = "INSERT INTO flights (flight_id, flight_code, airline, flight_date, flight_duration, " +
                     "departure_area_code, arrival_area_code, capacity, price) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        executeUpdate(sql, stmt -> {
            stmt.setString(1, flightId);
            stmt.setString(2, flightCode);
            stmt.setString(3, airline);
            if (flightDate != null) {
                stmt.setDate(4, new Date(flightDate.getTime()));
            } else {
                stmt.setDate(4, null);
            }
            stmt.setString(5, flightDuration);
            stmt.setString(6, departureAreaCode);
            stmt.setString(7, arrivalAreaCode);
            stmt.setInt(8, capacity);  // Total seats - all available for new flights
            stmt.setDouble(9, price);
        });
    }

    public void updateFlight(int id,
                             String flightId,
                             String flightCode,
                             String airline,
                             java.util.Date flightDate,
                             String flightDuration,
                             String departureAreaCode,
                             String arrivalAreaCode,
                             int capacity,
                             double price) throws SQLException {

        String sql = "UPDATE flights SET flight_id=?, flight_code=?, airline=?, flight_date=?, flight_duration=?, " +
                     "departure_area_code=?, arrival_area_code=?, capacity=?, price=? WHERE id=?";

        executeUpdate(sql, stmt -> {
            stmt.setString(1, flightId);
            stmt.setString(2, flightCode);
            stmt.setString(3, airline);
            if (flightDate != null) {
                stmt.setDate(4, new Date(flightDate.getTime()));
            } else {
                stmt.setDate(4, null);
            }
            stmt.setString(5, flightDuration);
            stmt.setString(6, departureAreaCode);
            stmt.setString(7, arrivalAreaCode);
            stmt.setInt(8, capacity);
            stmt.setDouble(9, price);
            stmt.setInt(10, id);
        });
    }

    public void deleteFlight(int id) throws SQLException {
        String sql = "DELETE FROM flights WHERE id=?";
        executeUpdate(sql, stmt -> stmt.setInt(1, id));
    }

    public List<String> searchFlights(String departureAreaCode, String arrivalAreaCode) throws SQLException {
        // Case-insensitive search using UPPER() function
        String sql = "SELECT * FROM flights WHERE UPPER(departure_area_code)=UPPER(?) AND UPPER(arrival_area_code)=UPPER(?)";
        List<String> flights = new ArrayList<>();

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, departureAreaCode.trim());
            stmt.setString(2, arrivalAreaCode.trim());

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    flights.add(
                        rs.getString("flight_code") + " - " +
                        rs.getString("airline") + " | " +
                        rs.getString("departure_area_code") + " -> " +
                        rs.getString("arrival_area_code") + " | " +
                        (rs.getString("flight_date") != null ? rs.getString("flight_date") : "N/A") + " | $" +
                        String.format("%.2f", rs.getDouble("price"))
                    );
                }
            }
        }
        return flights;
    }
    
    /**
     * Search flights and return Flight objects (for better integration with GUI)
     */
    public List<Flight> searchFlightsAsObjects(String departureAreaCode, String arrivalAreaCode) throws SQLException {
        return searchFlightsAsObjects(departureAreaCode, arrivalAreaCode, null);
    }
    
    /**
     * Search flights and return Flight objects with date filtering
     * @param departureAreaCode Departure area code
     * @param arrivalAreaCode Arrival area code
     * @param dateString Date in YYYY-MM-DD format (optional, can be null)
     */
    public List<Flight> searchFlightsAsObjects(String departureAreaCode, String arrivalAreaCode, String dateString) throws SQLException {
        // Build SQL query with optional date filter
        String sql = "SELECT * FROM flights WHERE UPPER(departure_area_code)=UPPER(?) AND UPPER(arrival_area_code)=UPPER(?)";
        if (dateString != null && !dateString.trim().isEmpty()) {
            sql += " AND DATE(flight_date) = DATE(?)";
        }
        
        List<Flight> flights = new ArrayList<>();

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, departureAreaCode.trim());
            stmt.setString(2, arrivalAreaCode.trim());
            if (dateString != null && !dateString.trim().isEmpty()) {
                stmt.setString(3, dateString.trim());
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    flights.add(mapFlight(rs));
                }
            }
        }
        return flights;
    }

    public int findFlightDbIdByBusinessId(String flightId) throws SQLException {
        String sql = "SELECT id FROM flights WHERE flight_id = ?";

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, flightId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        }
        return -1;
    }

    public List<Flight> getAllFlights() throws SQLException {
        String sql = "SELECT * FROM flights ORDER BY flight_date";
        List<Flight> flights = new ArrayList<>();

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                flights.add(mapFlight(rs));
            }
        }
        return flights;
    }

    public Flight findById(int id) throws SQLException {
        String sql = "SELECT * FROM flights WHERE id = ?";

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapFlight(rs);
                }
            }
        }
        return null;
    }

    public Flight findByFlightId(String flightId) throws SQLException {
        String sql = "SELECT * FROM flights WHERE flight_id = ?";

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, flightId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapFlight(rs);
                }
            }
        }
        return null;
    }

    private Flight mapFlight(ResultSet rs) throws SQLException {
        // SQLite stores dates as TEXT, so we need to parse them as strings
        java.util.Date flightDate = null;
        try {
            String dateStr = rs.getString("flight_date");
            if (dateStr != null && !dateStr.isEmpty()) {
                // Try to parse as SQL date first
                try {
                    java.sql.Date sqlDate = rs.getDate("flight_date");
                    if (sqlDate != null) {
                        flightDate = new java.util.Date(sqlDate.getTime());
                    }
                } catch (SQLException e) {
                    // If getDate fails, parse as string (YYYY-MM-DD format)
                    try {
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                        flightDate = sdf.parse(dateStr);
                    } catch (java.text.ParseException pe) {
                        // Date parsing failed, leave as null
                        System.err.println("Warning: Could not parse flight date: " + dateStr);
                    }
                }
            }
        } catch (Exception e) {
            // Date is null or invalid, continue with null
        }
        
        AreaCode departure = parseAreaCode(rs.getString("departure_area_code"));
        AreaCode arrival = parseAreaCode(rs.getString("arrival_area_code"));

        Flight flight = new Flight(
            rs.getString("flight_id"),
            rs.getString("flight_code"),
            rs.getString("airline"),
            flightDate,
            rs.getString("flight_duration"),
            departure,
            arrival
        );
        flight.setId(rs.getInt("id"));
        flight.setCapacity(rs.getInt("capacity"));
        flight.setPrice(rs.getDouble("price"));
        return flight;
    }

    /**
     * Calculates the number of available seats for a flight
     * Available seats = capacity (total seats) - number of confirmed bookings
     * 
     * For new flights: If capacity = 300 and no bookings exist, returns 300 (all seats available)
     * 
     * @param flightId The database ID of the flight
     * @return The number of available seats (minimum 0)
     *         For a new flight with capacity 300: returns 300 (300 / 300 available)
     */
    public int getAvailableSeats(int flightId) throws SQLException {
        Flight flight = findById(flightId);
        if (flight == null) {
            return 0;
        }
        
        int capacity = flight.getCapacity();  // Total seats from database schema
        int bookedSeats = new BookingDAO().countBookingsForFlight(flightId);  // Count confirmed bookings
        int available = capacity - bookedSeats;
        
        // Ensure we don't return negative values
        // For new flights: bookedSeats = 0, so available = capacity (all seats available)
        return Math.max(0, available);
    }

    private AreaCode parseAreaCode(String code) {
        if (code == null) return null;
        try {
            return AreaCode.valueOf(code);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}