package main.java.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Database Connection Manager
 * 
 * DESIGN PATTERN: Singleton Pattern
 * - Ensures only one database connection instance exists throughout the application
 * - Provides global access point to the database connection
 * - Lazy initialization with double-checked locking for thread safety
 * - Prevents multiple connection instances which could cause resource leaks
 * 
 * WHY SINGLETON?
 * - Database connections are expensive resources
 * - SQLite works best with a single connection instance
 * - Ensures consistent connection state across the application
 */
public class DBConnection {

    // DESIGN PATTERN: Singleton Pattern
    // The single instance of the class (Lazy Loading)
    private static DBConnection instance;
    private Connection connection;

    // Database constants
    // Database will be created in the project root directory
    private static final String DB_FILE = "air_travel.db";
    private static final String URL = "jdbc:sqlite:" + DB_FILE;

    // Private constructor prevents external instantiation
    private DBConnection() {
        createConnection();
    }

    private void createConnection() {
        try {
            // Load SQLite Driver (Xerial)
            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection(URL);
            // Enforce referential integrity
            this.connection.createStatement().execute("PRAGMA foreign_keys = ON");
        } 
        catch (Exception e) {
            throw new RuntimeException("Database connection failed", e);
        }
    }

    /**
     * Public access point to the single instance
     * DESIGN PATTERN: Singleton Pattern - Double-Checked Locking
     * - First check (outside synchronized) for performance
     * - Second check (inside synchronized) for thread safety
     * - Ensures only one instance is created even in multi-threaded environments
     */
    public static DBConnection getInstance() {
        if (instance == null) {
            // Synchronized block for thread safety
            synchronized (DBConnection.class) {
                if (instance == null) {
                    instance = new DBConnection();
                }
            }
        }
        return instance;
    }

    public Connection getConnection() throws SQLException {
        // Check if connection is closed or null, and reconnect if needed
        if (connection == null || connection.isClosed()) {
            synchronized (this) {
                if (connection == null || connection.isClosed()) {
                    createConnection();
                }
            }
        }
        return connection;
    }
}
