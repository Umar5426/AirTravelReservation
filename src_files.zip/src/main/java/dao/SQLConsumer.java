package main.java.dao;

import java.sql.SQLException;

/**
 * SQL Consumer Functional Interface
 * 
 * DESIGN PATTERN: Template Method Pattern (used with BaseDAO)
 * - Functional interface that allows lambdas to throw SQLException
 * - Used in BaseDAO.executeUpdate() to provide parameter-setting logic
 * - Enables Template Method pattern by allowing variable parts to be provided via lambda
 * 
 * WHY FUNCTIONAL INTERFACE?
 * - Allows concise lambda expressions for setting PreparedStatement parameters
 * - Makes Template Method pattern more elegant and readable
 * - Follows Java 8+ functional programming patterns
 */
@FunctionalInterface
public interface SQLConsumer<T> {
    /**
     * Accepts a parameter and performs an operation that may throw SQLException
     * Used in Template Method pattern to provide variable parameter-setting logic
     * 
     * @param t the parameter (typically PreparedStatement)
     * @throws SQLException if database operation fails
     */
    void accept(T t) throws SQLException;
}