package main.java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Base Data Access Object
 * 
 * DESIGN PATTERNS:
 * 1. Template Method Pattern - executeUpdate() defines the algorithm skeleton
 * 2. DAO Pattern - Base class for all data access objects
 * 3. Dependency Inversion - Uses Singleton (DBConnection) for connection management
 * 
 * WHY TEMPLATE METHOD?
 * - Eliminates code duplication across DAO classes
 * - Defines the algorithm structure (prepare, execute, close) once
 * - Subclasses only need to provide the variable part (parameter setting)
 * - Follows DRY (Don't Repeat Yourself) principle
 */
public abstract class BaseDAO {

    /**
     * Gets database connection from Singleton
     * DESIGN PATTERN: Singleton Pattern - Uses DBConnection.getInstance()
     */
    protected Connection getConnection() throws SQLException {
        return DBConnection.getInstance().getConnection();
    }

    /**
     * Template Method for INSERT, UPDATE, DELETE operations
     * DESIGN PATTERN: Template Method Pattern
     * 
     * Algorithm structure (fixed):
     * 1. Prepare statement
     * 2. Set parameters (variable - provided by consumer)
     * 3. Execute update
     * 4. Close statement (automatic via try-with-resources)
     * 
     * Subclasses only need to provide the parameter-setting logic via SQLConsumer
     * 
     * @param sql SQL statement to execute
     * @param consumer lambda/function that sets statement parameters
     */
    protected void executeUpdate(String sql, SQLConsumer<PreparedStatement> consumer) throws SQLException {
        try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
            consumer.accept(stmt); // The variable part (setting params)
            stmt.executeUpdate();
        }
    }
}