package main.java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Ensures the SQLite database exists with the required schema.
 */
public class DatabaseInitializer {

    private DatabaseInitializer() {
        // utility class
    }

    /**
     * Creates tables if they are missing and seeds sample data for demonstration.
     */
    public static void initializeDatabase() {
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            createTables(conn);
            seedUsers(conn);
            seedCustomers(conn);
            seedFlights(conn);
            seedBookings(conn);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize database: " + e.getMessage(), e);
        }
    }

    private static void createTables(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS customers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id TEXT NOT NULL UNIQUE,
                    fname TEXT NOT NULL,
                    lname TEXT NOT NULL,
                    dob DATE,
                    username TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL,
                    email TEXT,
                    phone TEXT
                )
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS flights (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    flight_id TEXT NOT NULL UNIQUE,
                    flight_code TEXT,
                    airline TEXT,
                    flight_date DATE,
                    flight_duration TEXT,
                    departure_area_code TEXT,
                    arrival_area_code TEXT,
                    capacity INTEGER,
                    price REAL
                )
            """);
            // Note: capacity represents the total number of seats available on the flight
            // Available seats = capacity - (number of confirmed bookings)

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS bookings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id INTEGER NOT NULL,
                    flight_id INTEGER NOT NULL,
                    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    status TEXT NOT NULL,
                    total_price REAL NOT NULL,
                    seat_number INTEGER,
                    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
                    FOREIGN KEY (flight_id) REFERENCES flights(id) ON DELETE CASCADE
                )
            """);
            
            // Add seat_number column if it doesn't exist (for existing databases)
            try {
                stmt.execute("ALTER TABLE bookings ADD COLUMN seat_number INTEGER");
            } catch (SQLException e) {
                // Column already exists, ignore
            }

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL,
                    role TEXT NOT NULL
                )
            """);
        }
    }

    private static void seedUsers(Connection conn) throws SQLException {
        String sql = """
            INSERT INTO users (username, password, role)
            SELECT ?, ?, ?
            WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = ?)
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            // Admin user
            ps.setString(1, "admin");
            ps.setString(2, "admin");
            ps.setString(3, "ADMIN");
            ps.setString(4, "admin");
            ps.executeUpdate();
            
            // Legacy admin user (moved from hardcoded to database)
            // This replaces the hardcoded "Captain"/"Abdul4" credentials
            ps.setString(1, "Captain");
            ps.setString(2, "Abdul4");
            ps.setString(3, "ADMIN");
            ps.setString(4, "Captain");
            ps.executeUpdate();
            
            // Flight Agent user
            ps.setString(1, "agent");
            ps.setString(2, "agent123");
            ps.setString(3, "AGENT");
            ps.setString(4, "agent");
            ps.executeUpdate();
        }
    }

    private static void seedCustomers(Connection conn) throws SQLException {
        String sql = """
            INSERT INTO customers (customer_id, fname, lname, dob, username, password, email, phone)
            SELECT ?, ?, ?, ?, ?, ?, ?, ?
            WHERE NOT EXISTS (SELECT 1 FROM customers WHERE customer_id = ?)
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            // Customer 1
            ps.setString(1, "CUST001");
            ps.setString(2, "John");
            ps.setString(3, "Smith");
            ps.setString(4, "1990-05-15");
            ps.setString(5, "john.smith");
            ps.setString(6, "password123");
            ps.setString(7, "john.smith@email.com");
            ps.setString(8, "555-0101");
            ps.setString(9, "CUST001");
            ps.executeUpdate();
            
            // Customer 2
            ps.setString(1, "CUST002");
            ps.setString(2, "Sarah");
            ps.setString(3, "Johnson");
            ps.setString(4, "1985-08-22");
            ps.setString(5, "sarah.j");
            ps.setString(6, "pass456");
            ps.setString(7, "sarah.j@email.com");
            ps.setString(8, "555-0102");
            ps.setString(9, "CUST002");
            ps.executeUpdate();
            
            // Customer 3
            ps.setString(1, "CUST003");
            ps.setString(2, "Michael");
            ps.setString(3, "Brown");
            ps.setString(4, "1992-11-30");
            ps.setString(5, "mike.brown");
            ps.setString(6, "mike789");
            ps.setString(7, "mike.brown@email.com");
            ps.setString(8, "555-0103");
            ps.setString(9, "CUST003");
            ps.executeUpdate();
            
            // Customer 4
            ps.setString(1, "CUST004");
            ps.setString(2, "Emily");
            ps.setString(3, "Davis");
            ps.setString(4, "1988-03-10");
            ps.setString(5, "emily.d");
            ps.setString(6, "emily123");
            ps.setString(7, "emily.davis@email.com");
            ps.setString(8, "555-0104");
            ps.setString(9, "CUST004");
            ps.executeUpdate();
        }
    }

    private static void seedFlights(Connection conn) throws SQLException {
        String sql = """
            INSERT INTO flights (flight_id, flight_code, airline, flight_date, flight_duration, 
                                departure_area_code, arrival_area_code, capacity, price)
            SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?
            WHERE NOT EXISTS (SELECT 1 FROM flights WHERE flight_id = ?)
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            // Flight 1: Toronto to Vancouver
            ps.setString(1, "AC101");
            ps.setString(2, "AC101");
            ps.setString(3, "Air Canada");
            ps.setString(4, "2024-12-20");
            ps.setString(5, "5h 30m");
            ps.setString(6, "YYZ");
            ps.setString(7, "YVR");
            ps.setInt(8, 200);
            ps.setDouble(9, 450.00);
            ps.setString(10, "AC101");
            ps.executeUpdate();
            
            // Flight 2: Vancouver to Los Angeles
            ps.setString(1, "WS202");
            ps.setString(2, "WS202");
            ps.setString(3, "WestJet");
            ps.setString(4, "2024-12-21");
            ps.setString(5, "2h 45m");
            ps.setString(6, "YVR");
            ps.setString(7, "LAX");
            ps.setInt(8, 180);
            ps.setDouble(9, 320.00);
            ps.setString(10, "WS202");
            ps.executeUpdate();
            
            // Flight 3: Montreal to New York
            ps.setString(1, "AC303");
            ps.setString(2, "AC303");
            ps.setString(3, "Air Canada");
            ps.setString(4, "2024-12-22");
            ps.setString(5, "1h 45m");
            ps.setString(6, "YUL");
            ps.setString(7, "JFK");
            ps.setInt(8, 150);
            ps.setDouble(9, 280.00);
            ps.setString(10, "AC303");
            ps.executeUpdate();
            
            // Flight 4: Calgary to Toronto
            ps.setString(1, "WS404");
            ps.setString(2, "WS404");
            ps.setString(3, "WestJet");
            ps.setString(4, "2024-12-23");
            ps.setString(5, "4h 15m");
            ps.setString(6, "YYC");
            ps.setString(7, "YYZ");
            ps.setInt(8, 190);
            ps.setDouble(9, 380.00);
            ps.setString(10, "WS404");
            ps.executeUpdate();
            
            // Flight 5: Toronto to London
            ps.setString(1, "AC505");
            ps.setString(2, "AC505");
            ps.setString(3, "Air Canada");
            ps.setString(4, "2024-12-24");
            ps.setString(5, "7h 30m");
            ps.setString(6, "YYZ");
            ps.setString(7, "LHR");
            ps.setInt(8, 300);
            ps.setDouble(9, 850.00);
            ps.setString(10, "AC505");
            ps.executeUpdate();
            
            // Flight 6: Vancouver to Tokyo
            ps.setString(1, "AC606");
            ps.setString(2, "AC606");
            ps.setString(3, "Air Canada");
            ps.setString(4, "2024-12-25");
            ps.setString(5, "9h 45m");
            ps.setString(6, "YVR");
            ps.setString(7, "HND");
            ps.setInt(8, 250);
            ps.setDouble(9, 1200.00);
            ps.setString(10, "AC606");
            ps.executeUpdate();
            
            // Flight 7: Montreal to Paris
            ps.setString(1, "AC707");
            ps.setString(2, "AC707");
            ps.setString(3, "Air Canada");
            ps.setString(4, "2024-12-26");
            ps.setString(5, "7h 15m");
            ps.setString(6, "YUL");
            ps.setString(7, "CDG");
            ps.setInt(8, 280);
            ps.setDouble(9, 920.00);
            ps.setString(10, "AC707");
            ps.executeUpdate();
            
            // Flight 8: Calgary to Seattle
            ps.setString(1, "WS808");
            ps.setString(2, "WS808");
            ps.setString(3, "WestJet");
            ps.setString(4, "2024-12-27");
            ps.setString(5, "2h 30m");
            ps.setString(6, "YYC");
            ps.setString(7, "SEA");
            ps.setInt(8, 160);
            ps.setDouble(9, 250.00);
            ps.setString(10, "WS808");
            ps.executeUpdate();
            
            // Flight 9: Toronto to Chicago
            ps.setString(1, "AC909");
            ps.setString(2, "AC909");
            ps.setString(3, "Air Canada");
            ps.setString(4, "2024-12-28");
            ps.setString(5, "2h 00m");
            ps.setString(6, "YYZ");
            ps.setString(7, "ORD");
            ps.setInt(8, 170);
            ps.setDouble(9, 290.00);
            ps.setString(10, "AC909");
            ps.executeUpdate();
            
            // Flight 10: Vancouver to San Francisco
            ps.setString(1, "WS1010");
            ps.setString(2, "WS1010");
            ps.setString(3, "WestJet");
            ps.setString(4, "2024-12-29");
            ps.setString(5, "2h 20m");
            ps.setString(6, "YVR");
            ps.setString(7, "SFO");
            ps.setInt(8, 175);
            ps.setDouble(9, 310.00);
            ps.setString(10, "WS1010");
            ps.executeUpdate();
        }
    }

    private static void seedBookings(Connection conn) throws SQLException {
        // First, we need to get the IDs of customers and flights
        // This is a simplified approach - in production, you'd query first
        
        String sql = """
            INSERT INTO bookings (customer_id, flight_id, booking_date, status, total_price)
            SELECT 
                (SELECT id FROM customers WHERE customer_id = ? LIMIT 1),
                (SELECT id FROM flights WHERE flight_id = ? LIMIT 1),
                datetime('now', '-' || ? || ' days'),
                ?,
                ?
            WHERE NOT EXISTS (
                SELECT 1 FROM bookings b
                JOIN customers c ON b.customer_id = c.id
                JOIN flights f ON b.flight_id = f.id
                WHERE c.customer_id = ? AND f.flight_id = ?
            )
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            // Booking 1: John Smith - AC101 (Toronto to Vancouver)
            ps.setString(1, "CUST001");
            ps.setString(2, "AC101");
            ps.setInt(3, 5); // 5 days ago
            ps.setString(4, "CONFIRMED");
            ps.setDouble(5, 450.00);
            ps.setString(6, "CUST001");
            ps.setString(7, "AC101");
            ps.executeUpdate();
            
            // Booking 2: Sarah Johnson - AC303 (Montreal to New York)
            ps.setString(1, "CUST002");
            ps.setString(2, "AC303");
            ps.setInt(3, 3); // 3 days ago
            ps.setString(4, "CONFIRMED");
            ps.setDouble(5, 280.00);
            ps.setString(6, "CUST002");
            ps.setString(7, "AC303");
            ps.executeUpdate();
            
            // Booking 3: Michael Brown - WS404 (Calgary to Toronto)
            ps.setString(1, "CUST003");
            ps.setString(2, "WS404");
            ps.setInt(3, 7); // 7 days ago
            ps.setString(4, "CONFIRMED");
            ps.setDouble(5, 380.00);
            ps.setString(6, "CUST003");
            ps.setString(7, "WS404");
            ps.executeUpdate();
            
            // Booking 4: John Smith - AC505 (Toronto to London) - second booking
            ps.setString(1, "CUST001");
            ps.setString(2, "AC505");
            ps.setInt(3, 2); // 2 days ago
            ps.setString(4, "CONFIRMED");
            ps.setDouble(5, 850.00);
            ps.setString(6, "CUST001");
            ps.setString(7, "AC505");
            ps.executeUpdate();
            
            // Booking 5: Emily Davis - WS808 (Calgary to Seattle)
            ps.setString(1, "CUST004");
            ps.setString(2, "WS808");
            ps.setInt(3, 1); // 1 day ago
            ps.setString(4, "CONFIRMED");
            ps.setDouble(5, 250.00);
            ps.setString(6, "CUST004");
            ps.setString(7, "WS808");
            ps.executeUpdate();
        }
    }
}
