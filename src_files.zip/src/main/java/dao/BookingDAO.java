package main.java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import main.java.model.AreaCode;
import main.java.model.Customer;
import main.java.model.Flight;
import main.java.model.Reservation;

public class BookingDAO extends BaseDAO {

    public int createBooking(int customerId, int flightId, double totalPrice) throws SQLException {
        return createBooking(customerId, flightId, totalPrice, null);
    }
    
    public int createBooking(int customerId, int flightId, double totalPrice, Integer seatNumber) throws SQLException {
        // We use RETURN_GENERATED_KEYS here, so we do manual JDBC instead of the template
        String sql = "INSERT INTO bookings (customer_id, flight_id, booking_date, status, total_price, seat_number) " +
                     "VALUES (?, ?, CURRENT_TIMESTAMP, 'CONFIRMED', ?, ?)";

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, customerId);
            stmt.setInt(2, flightId);
            stmt.setDouble(3, totalPrice);
            if (seatNumber != null) {
                stmt.setInt(4, seatNumber);
            } else {
                stmt.setNull(4, java.sql.Types.INTEGER);
            }

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1; // Failure
    }

    public void cancelBooking(int bookingId) throws SQLException {
        // Actually delete the booking instead of just marking as cancelled
        String sql = "DELETE FROM bookings WHERE id=?";
        executeUpdate(sql, stmt -> stmt.setInt(1, bookingId));
    }

    public String getBookingInfo(int bookingId) throws SQLException {
        // Complex join query
        String sql = "SELECT b.id, b.booking_date, b.status, b.total_price, " +
                     "c.customer_id, c.fname, c.lname, c.email, " +
                     "f.flight_id, f.flight_code, f.departure_area_code, f.arrival_area_code " +
                     "FROM bookings b " +
                     "JOIN customers c ON b.customer_id = c.id " +
                     "JOIN flights f ON b.flight_id = f.id " +
                     "WHERE b.id=?";

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bookingId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return "Booking #" + rs.getInt("id") +
                           "\nCustomer: " + rs.getString("fname") + " " + rs.getString("lname") +
                           " [" + rs.getString("customer_id") + "]" +
                           (rs.getString("email") != null ? " (" + rs.getString("email") + ")" : "") +
                           "\nFlight: " + rs.getString("flight_id") + " (" + rs.getString("flight_code") + ")" +
                           " | " + rs.getString("departure_area_code") +
                           " -> " + rs.getString("arrival_area_code") +
                           "\nStatus: " + rs.getString("status") +
                           "\nTotal: $" + rs.getDouble("total_price") +
                           "\nDate: " + rs.getTimestamp("booking_date");
                }
            }
        }
        return "Booking not found.";
    }

    public List<Reservation> getReservationsForCustomer(int customerDbId) throws SQLException {
        // Only get active (non-cancelled) bookings for this specific customer
        String sql = "SELECT b.id AS booking_id, b.booking_date, b.status, b.total_price, b.seat_number, " +
                     "c.id AS c_id, c.customer_id AS c_customer_id, c.fname AS c_fname, c.lname AS c_lname, " +
                     "c.dob AS c_dob, c.username AS c_username, c.password AS c_password, c.email AS c_email, c.phone AS c_phone, " +
                     "f.id AS f_id, f.flight_id, f.flight_code, f.airline, f.flight_date, f.flight_duration, " +
                     "f.departure_area_code, f.arrival_area_code, f.capacity, f.price " +
                     "FROM bookings b " +
                     "JOIN flights f ON b.flight_id = f.id " +
                     "JOIN customers c ON b.customer_id = c.id " +
                     "WHERE c.id = ? AND (b.status IS NULL OR b.status != 'CANCELLED') " +
                     "ORDER BY b.booking_date DESC";

        List<Reservation> reservations = new ArrayList<>();

        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, customerDbId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int bookingId = rs.getInt("booking_id");
                    Customer customer = buildCustomer(rs);
                    Flight flight = buildFlight(rs);
                    Timestamp bookedAt = rs.getTimestamp("booking_date");
                    Date dateBooked = bookedAt != null ? new Date(bookedAt.getTime()) : new Date();
                    double totalPrice = rs.getDouble("total_price");
                    Integer seatNumber = null;
                    try {
                        int seatNum = rs.getInt("seat_number");
                        if (!rs.wasNull()) {
                            seatNumber = seatNum;
                        }
                    } catch (SQLException e) {
                        // seat_number might be null, that's okay
                    }
                    
                    // Use constructor that sets reservation ID from booking ID
                    Reservation reservation = new Reservation(bookingId, customer, flight, dateBooked, totalPrice);
                    reservation.setSeatNumber(seatNumber);
                    reservations.add(reservation);
                }
            }
        }
        return reservations;
    }

    private Customer buildCustomer(ResultSet rs) throws SQLException {
        // SQLite stores dates as TEXT, so we need to parse them as strings
        java.util.Date dob = null;
        try {
            String dateStr = rs.getString("c_dob");
            if (dateStr != null && !dateStr.isEmpty()) {
                try {
                    java.sql.Date sqlDate = rs.getDate("c_dob");
                    if (sqlDate != null) {
                        dob = new java.util.Date(sqlDate.getTime());
                    }
                } catch (SQLException e) {
                    try {
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                        dob = sdf.parse(dateStr);
                    } catch (java.text.ParseException pe) {
                        // Date parsing failed, leave as null
                    }
                }
            }
        } catch (Exception e) {
            // Date is null or invalid, continue with null
        }

        return new Customer(
            rs.getInt("c_id"),
            rs.getString("c_fname"),
            rs.getString("c_lname"),
            dob,
            rs.getString("c_customer_id"),
            rs.getString("c_username"),
            rs.getString("c_password"),
            rs.getString("c_email"),
            rs.getString("c_phone")
        );
    }

    private Flight buildFlight(ResultSet rs) throws SQLException {
        // SQLite stores dates as TEXT, so we need to parse them as strings
        java.util.Date flightDate = null;
        try {
            String dateStr = rs.getString("flight_date");
            if (dateStr != null && !dateStr.isEmpty()) {
                // Try to parse as SQL date first
                try {
                    java.sql.Date sqlDate = rs.getDate("flight_date");
                    if (sqlDate != null) {
                        flightDate = new java.util.Date(sqlDate.getTime());
                    }
                } catch (SQLException e) {
                    // If getDate fails, parse as string (YYYY-MM-DD format)
                    try {
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                        flightDate = sdf.parse(dateStr);
                    } catch (java.text.ParseException pe) {
                        // Date parsing failed, leave as null
                        System.err.println("Warning: Could not parse flight date: " + dateStr);
                    }
                }
            }
        } catch (Exception e) {
            // Date is null or invalid, continue with null
        }
        
        Flight flight = new Flight(
            rs.getString("flight_id"),
            rs.getString("flight_code"),
            rs.getString("airline"),
            flightDate,
            rs.getString("flight_duration"),
            parseAreaCode(rs.getString("departure_area_code")),
            parseAreaCode(rs.getString("arrival_area_code"))
        );
        flight.setId(rs.getInt("f_id"));
        flight.setCapacity(rs.getInt("capacity"));
        flight.setPrice(rs.getDouble("price"));
        return flight;
    }

    /**
     * Counts the number of confirmed bookings for a specific flight
     * @param flightId The database ID of the flight
     * @return The number of confirmed bookings (excluding cancelled ones)
     */
    public int countBookingsForFlight(int flightId) throws SQLException {
        String sql = "SELECT COUNT(*) as booking_count FROM bookings " +
                     "WHERE flight_id = ? AND (status IS NULL OR status != 'CANCELLED')";
        
        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, flightId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("booking_count");
                }
            }
        }
        return 0;
    }
    
    /**
     * Gets list of booked seat numbers for a flight
     * @param flightId The database ID of the flight
     * @return List of seat numbers that are already booked
     */
    public List<Integer> getBookedSeats(int flightId) throws SQLException {
        String sql = "SELECT seat_number FROM bookings " +
                     "WHERE flight_id = ? AND (status IS NULL OR status != 'CANCELLED') AND seat_number IS NOT NULL";
        
        List<Integer> bookedSeats = new ArrayList<>();
        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, flightId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int seatNum = rs.getInt("seat_number");
                    if (!rs.wasNull()) {
                        bookedSeats.add(seatNum);
                    }
                }
            }
        }
        return bookedSeats;
    }
    
    /**
     * Gets the seat number for a specific booking
     * @param bookingId The database ID of the booking
     * @return The seat number, or null if not set
     */
    public Integer getSeatNumber(int bookingId) throws SQLException {
        String sql = "SELECT seat_number FROM bookings WHERE id = ?";
        
        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, bookingId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int seatNum = rs.getInt("seat_number");
                    if (!rs.wasNull()) {
                        return seatNum;
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Updates the seat number for a booking
     * @param bookingId The database ID of the booking
     * @param seatNumber The new seat number (can be null to clear seat assignment)
     */
    public void updateSeatNumber(int bookingId, Integer seatNumber) throws SQLException {
        String sql = "UPDATE bookings SET seat_number = ? WHERE id = ?";
        
        Connection conn = getConnection();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (seatNumber != null) {
                stmt.setInt(1, seatNumber);
            } else {
                stmt.setNull(1, java.sql.Types.INTEGER);
            }
            stmt.setInt(2, bookingId);
            
            stmt.executeUpdate();
        }
    }

    private AreaCode parseAreaCode(String code) {
        if (code == null) return null;
        try {
            return AreaCode.valueOf(code);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
