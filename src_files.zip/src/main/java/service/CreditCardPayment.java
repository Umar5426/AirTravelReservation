package main.java.service;

import main.java.model.Customer;

/**
 * Credit Card Payment Strategy
 * 
 * DESIGN PATTERN: Strategy Pattern - Concrete Strategy
 * - Implements PaymentStrategy interface
 * - Encapsulates credit card payment algorithm
 * - Can be swapped with other payment strategies at runtime
 */
public class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    private Customer cardHolder;

    public CreditCardPayment(String cardNumber, Customer cardHolder) {
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
    }

    /**
     * Executes credit card payment
     * DESIGN PATTERN: Strategy Pattern - Concrete implementation
     */
    @Override
    public boolean pay(Customer cardHolder, double amount) {
        // In production, this would integrate with payment gateway
        System.out.println(cardHolder.getFname() + " paid " + amount + " using Credit Card: " + cardNumber);
        return true;
    }
}
