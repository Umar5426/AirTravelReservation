package main.java.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import main.java.dao.AuthorizationDAO;
import main.java.dao.BookingDAO;
import main.java.dao.CustomerDAO;
import main.java.dao.FlightDAO;
import main.java.model.Customer;
import main.java.model.Flight;
import main.java.model.Reservation;

/**
 * Customer Service
 * 
 * DESIGN PATTERNS:
 * 1. DAO Pattern - All data access through DAO layer, not direct database calls
 * 2. Single Responsibility - Handles customer-related business logic
 * 3. Dependency Injection - DAOs are dependencies (could be injected via constructor in production)
 * 
 * NOTE: This service combines authentication, flight search, and booking operations
 * for backward compatibility with existing GUI code.
 */
public class CustomerService {

    private Customer loggedInCustomer;

    // DESIGN PATTERN: DAO Pattern - All data access through DAO layer
    // In production, these would be injected via constructor (Dependency Injection)
    private AuthorizationDAO authDAO = new AuthorizationDAO();
    private CustomerDAO customerDAO = new CustomerDAO();
    private FlightDAO flightDAO = new FlightDAO();
    private BookingDAO bookingDAO = new BookingDAO();

    // ---------------------
    // Authentication
    // ---------------------

    /**
     * Authenticates a user by checking both users and customers tables
     * DESIGN PATTERN: DAO Pattern - All authentication through database, no hardcoded credentials
     */
    public boolean login(String username, String password) {
        try {
            // First check users table (for admin/agent roles)
            String role = authDAO.login(username, password);
            if (role != null) {
                // Check if it's also a customer in customers table
                Customer customer = customerDAO.findByCredentials(username, password);
                if (customer != null) {
                    loggedInCustomer = customer;
                } else {
                    // Minimal customer stub for admin/agent users
                    loggedInCustomer = new Customer(-1, username, "", null, username, username, password, null, null);
                }
                return true;
            }
            
            // Try customers table directly
            Customer customer = customerDAO.findByCredentials(username, password);
            if (customer != null) {
                loggedInCustomer = customer;
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void logout() {
        loggedInCustomer = null;
    }

    public Customer getLoggedInCustomer() {
        return loggedInCustomer;
    }

    /**
     * Registers a new customer with auto-generated customer ID
     * DESIGN PATTERN: DAO Pattern - All data access through DAO layer
     * Customer ID is auto-generated and hidden from users (only admins can see it)
     */
    public boolean register(String firstName, String lastName, 
                           java.util.Date dob, String username, String password,
                           String email, String phone) {
        try {
            // Check if username already exists
            Customer existing = customerDAO.findByUsername(username);
            if (existing != null) {
                return false; // Username already taken
            }
            
            // Auto-generate customer ID (hidden from user)
            String customerId = customerDAO.generateNextCustomerId();
            
            // Add new customer
            customerDAO.addCustomer(customerId, firstName, lastName, dob, 
                                  username, password, email, phone);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ---------------------
    // Flight Searching (Using DAO)
    // ---------------------

    /**
     * Searches for flights using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public List<String> searchFlights(String departure, String destination) {
        try {
            return flightDAO.searchFlights(departure, destination);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // ---------------------
    // Flight Details
    // ---------------------

    public Flight viewFlight(String flightCode) {
        try {
            return flightDAO.findByFlightId(flightCode);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Flight viewFlightById(int id) {
        try {
            return flightDAO.findById(id);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // ---------------------
    // Reservation Handling
    // ---------------------

    /**
     * Creates a reservation using DAO
     * DESIGN PATTERN: DAO Pattern - All booking operations through BookingDAO
     */
    public Reservation makeReservation(String flightCode) {
        return makeReservation(flightCode, null);
    }
    
    /**
     * Creates a reservation with seat selection using DAO
     * DESIGN PATTERN: DAO Pattern - All booking operations through BookingDAO
     */
    public Reservation makeReservation(String flightCode, Integer seatNumber) {
        if (loggedInCustomer == null) return null;

        Flight flight = viewFlight(flightCode);
        if (flight == null) return null;

        try {
            int customerDbId = loggedInCustomer.getId();
            if (customerDbId == -1) {
                customerDbId = customerDAO.findCustomerIdByBusinessId(loggedInCustomer.getCustomerID());
            }
            
            int flightDbId = flight.getId();
            if (flightDbId == 0) {
                flightDbId = flightDAO.findFlightDbIdByBusinessId(flight.getFlightID());
            }

            if (customerDbId == -1 || flightDbId == -1) {
                return null;
            }

            // Validate seat is still available before booking
            if (seatNumber != null) {
                List<Integer> bookedSeats = bookingDAO.getBookedSeats(flightDbId);
                if (bookedSeats.contains(seatNumber)) {
                    // Seat is already taken
                    return null;
                }
                
                // Also validate seat is within capacity
                if (seatNumber < 1 || seatNumber > flight.getCapacity()) {
                    // Invalid seat number
                    return null;
                }
            }

            int bookingId = bookingDAO.createBooking(customerDbId, flightDbId, flight.getPrice(), seatNumber);
            if (bookingId == -1) return null;

            Reservation newRes = new Reservation(loggedInCustomer, flight);
            newRes.setBookingDbId(bookingId);
            return newRes;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Creates a reservation for a specific customer (used by agents)
     * DESIGN PATTERN: DAO Pattern - All booking operations through BookingDAO
     */
    public Reservation makeReservationForCustomer(String flightCode, String customerUsername) {
        return makeReservationForCustomer(flightCode, customerUsername, null);
    }
    
    /**
     * Creates a reservation for a specific customer with seat selection (used by agents)
     * DESIGN PATTERN: DAO Pattern - All booking operations through BookingDAO
     */
    public Reservation makeReservationForCustomer(String flightCode, String customerUsername, Integer seatNumber) {
        try {
            // Find customer by username
            Customer customer = customerDAO.findByUsername(customerUsername);
            if (customer == null) {
                return null;
            }

            Flight flight = viewFlight(flightCode);
            if (flight == null) return null;

            int customerDbId = customer.getId();
            if (customerDbId == -1) {
                customerDbId = customerDAO.findCustomerIdByBusinessId(customer.getCustomerID());
            }
            
            int flightDbId = flight.getId();
            if (flightDbId == 0) {
                flightDbId = flightDAO.findFlightDbIdByBusinessId(flight.getFlightID());
            }

            if (customerDbId == -1 || flightDbId == -1) {
                return null;
            }

            // Validate seat is still available before booking
            if (seatNumber != null) {
                List<Integer> bookedSeats = bookingDAO.getBookedSeats(flightDbId);
                if (bookedSeats.contains(seatNumber)) {
                    // Seat is already taken
                    return null;
                }
                
                // Also validate seat is within capacity
                if (seatNumber < 1 || seatNumber > flight.getCapacity()) {
                    // Invalid seat number
                    return null;
                }
            }

            int bookingId = bookingDAO.createBooking(customerDbId, flightDbId, flight.getPrice(), seatNumber);
            if (bookingId == -1) return null;

            Reservation newRes = new Reservation(customer, flight);
            newRes.setBookingDbId(bookingId);
            return newRes;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Gets customer by username (used by agents)
     * DESIGN PATTERN: DAO Pattern
     */
    public Customer getCustomerByUsername(String username) {
        try {
            return customerDAO.findByUsername(username);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Cancels a reservation using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public boolean cancelReservation(String reservationID) {
        try {
            if (loggedInCustomer != null) {
                int customerDbId = loggedInCustomer.getId();
                if (customerDbId != -1) {
                    List<Reservation> dbReservations = bookingDAO.getReservationsForCustomer(customerDbId);
                    for (Reservation r : dbReservations) {
                        if (r.getReservationID().equals(reservationID)) {
                            bookingDAO.cancelBooking(r.getBookingDbId());
                            return true;
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Updates the seat number for a reservation
     * @param reservationID The reservation ID
     * @param newSeatNumber The new seat number
     * @return true if successful, false otherwise
     */
    public boolean updateSeatNumber(String reservationID, Integer newSeatNumber) {
        try {
            if (loggedInCustomer != null) {
                int customerDbId = loggedInCustomer.getId();
                if (customerDbId != -1) {
                    List<Reservation> dbReservations = bookingDAO.getReservationsForCustomer(customerDbId);
                    for (Reservation r : dbReservations) {
                        if (r.getReservationID().equals(reservationID)) {
                            return updateSeatNumberForReservation(r, newSeatNumber);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Updates seat number for any reservation (used by agents)
     * @param bookingDbId The booking database ID
     * @param newSeatNumber The new seat number
     * @return true if successful, false otherwise
     */
    public boolean updateSeatNumberForBooking(int bookingDbId, Integer newSeatNumber) {
        try {
            // Get the reservation by booking ID
            List<Customer> allCustomers = customerDAO.getCustomerRecords();
            for (Customer customer : allCustomers) {
                List<Reservation> reservations = bookingDAO.getReservationsForCustomer(customer.getId());
                for (Reservation r : reservations) {
                    if (r.getBookingDbId() == bookingDbId) {
                        return updateSeatNumberForReservation(r, newSeatNumber);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Helper method to update seat number for a reservation
     */
    private boolean updateSeatNumberForReservation(Reservation r, Integer newSeatNumber) {
        try {
            // Check if new seat is available (excluding current seat)
            int flightId = r.getFlight().getId();
            if (flightId <= 0) {
                flightId = flightDAO.findFlightDbIdByBusinessId(r.getFlight().getFlightID());
            }
            
            if (flightId > 0) {
                List<Integer> bookedSeats = bookingDAO.getBookedSeats(flightId);
                // Remove current seat from booked list if it exists
                if (r.getSeatNumber() != null) {
                    bookedSeats.remove(r.getSeatNumber());
                }
                
                // Check if new seat is available
                if (newSeatNumber != null && bookedSeats.contains(newSeatNumber)) {
                    return false; // Seat already taken
                }
                
                // Check if seat number is within capacity
                Flight flight = r.getFlight();
                if (newSeatNumber != null && (newSeatNumber < 1 || newSeatNumber > flight.getCapacity())) {
                    return false; // Invalid seat number
                }
                
                // Update seat number
                bookingDAO.updateSeatNumber(r.getBookingDbId(), newSeatNumber);
                r.setSeatNumber(newSeatNumber);
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean modifyReservation(String reservationID, String newFlightCode) {
        if (loggedInCustomer == null) return false;

        try {
            int customerDbId = loggedInCustomer.getId();
            if (customerDbId != -1) {
                List<Reservation> reservations = bookingDAO.getReservationsForCustomer(customerDbId);
                for (Reservation r : reservations) {
                    if (r.getReservationID().equals(reservationID)) {
                        Flight newFlight = viewFlight(newFlightCode);
                        if (newFlight != null) {
                            r.setFlight(newFlight);
                            return true;
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Gets booking history using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public List<Reservation> viewBookingHistory() {
        if (loggedInCustomer == null) return new ArrayList<>();

        try {
            int customerDbId = loggedInCustomer.getId();
            if (customerDbId != -1) {
                return bookingDAO.getReservationsForCustomer(customerDbId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }
}
