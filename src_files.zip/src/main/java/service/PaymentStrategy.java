package main.java.service;

import main.java.model.Customer;

/**
 * Payment Strategy Interface
 * 
 * DESIGN PATTERN: Strategy Pattern
 * - Defines family of algorithms (payment methods) that are interchangeable
 * - Encapsulates each payment algorithm in a separate class
 * - Makes algorithms independent of the clients that use them
 * - Follows Open/Closed Principle - can add new payment methods without modifying existing code
 * 
 * WHY STRATEGY?
 * - Different payment methods (Credit Card, PayPal) have different implementations
 * - Payment method can be selected at runtime
 * - Easy to add new payment methods (e.g., Apple Pay, Google Pay) without changing PaymentSystem
 */
public interface PaymentStrategy {
    /**
     * Executes payment using the specific strategy
     * @param cardHolder customer making the payment
     * @param amount payment amount
     * @return true if payment successful, false otherwise
     */
    boolean pay(Customer cardHolder, double amount);
}

