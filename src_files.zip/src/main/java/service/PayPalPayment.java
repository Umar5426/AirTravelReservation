package main.java.service;

import main.java.model.Customer;

/**
 * PayPal Payment Strategy
 * 
 * DESIGN PATTERN: Strategy Pattern - Concrete Strategy
 * - Implements PaymentStrategy interface
 * - Encapsulates PayPal payment algorithm
 * - Can be swapped with other payment strategies at runtime
 */
public class PayPalPayment implements PaymentStrategy {
    private String email;
    private Customer cardHolder;

    public PayPalPayment(Customer cardHolder, String email) {
        this.email = email;
        this.cardHolder = cardHolder;
    }

    /**
     * Executes PayPal payment
     * DESIGN PATTERN: Strategy Pattern - Concrete implementation
     */
    @Override
    public boolean pay(Customer cardHolder, double amount) {
        // In production, this would integrate with PayPal API
        System.out.println(cardHolder.getFname() + " paid " + amount + " using PayPal account: " + email);
        return true;
    }
}
