package main.java.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import main.java.model.Customer;
import main.java.model.Reservation;
import main.java.dao.BookingDAO;
import main.java.dao.CustomerDAO;
import main.java.dao.FlightDAO;
import main.java.model.Flight;
import java.sql.SQLException;

/**
 * Booking Service
 * 
 * DESIGN PATTERNS:
 * 1. DAO Pattern - All booking data access through BookingDAO
 * 2. Single Responsibility - Handles booking/reservation business logic
 * 
 * NOTE: This service provides booking operations. In a larger system,
 * this might implement an IBookingService interface for better testability.
 */
public class BookingService {
    
    // DESIGN PATTERN: DAO Pattern - All data access through DAO layer
    private BookingDAO bookingDAO = new BookingDAO();
    private CustomerDAO customerDAO = new CustomerDAO();
    private FlightDAO flightDAO = new FlightDAO();

    public BookingService() {
        // Constructor - DAOs initialized here
        // In production, DAOs would be injected via constructor (Dependency Injection)
    }

    /**
     * Makes a reservation using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public void makeReservation(Reservation reservation) {
        try {
            Customer customer = reservation.getCustomer();
            Flight flight = reservation.getFlight();
            
            int customerDbId = customer.getId();
            if (customerDbId == -1) {
                customerDbId = customerDAO.findCustomerIdByBusinessId(customer.getCustomerID());
            }
            
            int flightDbId = flight.getId();
            if (flightDbId == 0) {
                flightDbId = flightDAO.findFlightDbIdByBusinessId(flight.getFlightID());
            }

            if (customerDbId != -1 && flightDbId != -1) {
                int bookingId = bookingDAO.createBooking(customerDbId, flightDbId, flight.getPrice());
                if (bookingId != -1) {
                    reservation.setBookingDbId(bookingId);
        System.out.println("BookingService: Reservation created for flight " 
                                       + flight.getFlightCode());
    }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Modifies a reservation using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public void modifyReservation(Reservation oldReservation, Reservation newReservation) {
        // For now, this updates the reservation object
        // In a full implementation, we'd update the database via DAO
            System.out.println("BookingService: Reservation updated.");
    }

    /**
     * Cancels a reservation using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public void cancelReservation(Reservation reservation) {
        try {
            if (reservation.getBookingDbId() != -1) {
                bookingDAO.cancelBooking(reservation.getBookingDbId());
        System.out.println("BookingService: Reservation cancelled.");
    }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Gets booking history using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public List<Reservation> getBookingHistory(Customer customer) {
        try {
            int customerDbId = customer.getId();
            if (customerDbId != -1) {
                return bookingDAO.getReservationsForCustomer(customerDbId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            }
        return Collections.unmodifiableList(new ArrayList<>());
    }

    /**
     * Generates booking confirmation
     * DESIGN PATTERN: Template Method (implicit) - Defines structure for confirmation generation
     */
    public String generateBookingConfirmation(Reservation reservation) {
        return "Booking Confirmation:\n" +
               "Customer: " + reservation.getCustomer().getFname() + " " + reservation.getCustomer().getLname() + "\n" +
               "Flight: " + reservation.getFlight().getFlightCode() + "\n" +
               "Date Booked: " + reservation.getDateBooked();
    }
}
