package main.java.service;

import main.java.model.Flight;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.sql.SQLException;
import main.java.dao.FlightDAO;

/**
 * Flight Service
 * 
 * DESIGN PATTERNS:
 * 1. DAO Pattern - All flight data access through FlightDAO
 * 2. Single Responsibility - Handles flight-related business logic
 * 
 * NOTE: This service provides both read operations (for customers) and
 * management operations (for admins). In a larger system, these might be
 * separated into IFlightService and IFlightManagementService interfaces.
 */
public class FlightService {

    // DESIGN PATTERN: DAO Pattern
    private FlightDAO flightDAO = new FlightDAO();

    public FlightService() {
        // Constructor - DAO initialized here
        // In production, DAO would be injected via constructor (Dependency Injection)
    }

    // CREATE – Add a new flight
    /**
     * Adds a flight using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public void addFlight(Flight flight) {
        try {
            flightDAO.addFlight(
                flight.getFlightID(),
                flight.getFlightCode(),
                flight.getAirLine(),
                flight.getFlightDate(),
                flight.getFlightDuration(),
                flight.getDepartureAreaCode() != null ? flight.getDepartureAreaCode().name() : null,
                flight.getArrivalAreaCode() != null ? flight.getArrivalAreaCode().name() : null,
                flight.getCapacity(),
                flight.getPrice()
            );
            System.out.println("FlightService: addFlight() is called for " + flight.getFlightCode());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Updating – Updates an existing flight
    /**
     * Updates a flight using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public void updateFlight(String flightID, Flight updatedFlight) {
        try {
            int dbId = flightDAO.findFlightDbIdByBusinessId(flightID);
            if (dbId != -1) {
                flightDAO.updateFlight(
                    dbId,
                    updatedFlight.getFlightID(),
                    updatedFlight.getFlightCode(),
                    updatedFlight.getAirLine(),
                    updatedFlight.getFlightDate(),
                    updatedFlight.getFlightDuration(),
                    updatedFlight.getDepartureAreaCode() != null ? updatedFlight.getDepartureAreaCode().name() : null,
                    updatedFlight.getArrivalAreaCode() != null ? updatedFlight.getArrivalAreaCode().name() : null,
                    updatedFlight.getCapacity(),
                    updatedFlight.getPrice()
                );
                System.out.println("FlightService: flight has been updated.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete – Delete a flight by ID
    /**
     * Deletes a flight using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public void deleteFlight(String flightID) {
        try {
            int dbId = flightDAO.findFlightDbIdByBusinessId(flightID);
            if (dbId != -1) {
                flightDAO.deleteFlight(dbId);
                System.out.println("FlightService: deleteFlight() is called for ID " + flightID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Read – Get all flights (view flight schedule)
    /**
     * Gets all flights using DAO
     * DESIGN PATTERN: DAO Pattern
     */
    public List<Flight> getAllFlights() {
        try {
            return flightDAO.getAllFlights();
        } catch (SQLException e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
}
